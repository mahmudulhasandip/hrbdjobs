<?php $__env->startSection('title', 'HRBDJobs | Employer Shortlisted Candidate'); ?>

<?php $__env->startSection('content'); ?>
	<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
							<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column mb-50">
				 		<div class="padding-left">
                            <div class="widget shortlist">
                                <h3 class="sb-title open">Software Engineer</h3>
                                <div class="tree_widget-sec">
                                    <ul>
                                        <li class="inner-child">
                                            Mahmudul Hasan Dip
											<span style="display:block;">2 years experience</span>
											
											<a href="#"><i class="la la-trash-o"></i></a>
										</li>
										<li class="inner-child">
                                            Mahmudul Hasan Dip
											<span style="display:block;">2 years experience</span>
											
											<a href="#"><i class="la la-trash-o"></i></a>
                                        </li>
                                    </ul>
								</div>
							</div>
							
							<div class="widget shortlist">
                                <h3 class="sb-title open">Software Engineer</h3>
                                <div class="tree_widget-sec">
                                    <ul>
                                        <li class="inner-child">
                                            Mahmudul Hasan Dip
											<span style="display:block;">2 years experience</span>
											
											<a href="#"><i class="la la-trash-o"></i></a>
										</li>
										<li class="inner-child">
                                            Mahmudul Hasan Dip
											<span style="display:block;">2 years experience</span>
											
											<a href="#"><i class="la la-trash-o"></i></a>
                                        </li>
                                    </ul>
								</div>
								
								
                            </div>
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>