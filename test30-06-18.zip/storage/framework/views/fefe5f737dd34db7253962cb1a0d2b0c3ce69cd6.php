<?php $__env->startSection('title', 'HRBDJobs | Employer Dashboard'); ?>

<?php $__env->startSection('content'); ?>
	<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(<?php echo e(asset('/images/top-bg.jpg')); ?>) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
				 			<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column">
				 		<div class="padding-left">
					 		<div class="manage-jobs-sec mb50">
					 			<h3>Packages</h3>
						 		

                                 <div class="col-sm-8 col-sm-offset-1">
                                    <div class="package_details mb50">

                                        <ul>

                                            <li>
                                                <span class="pull-left">Date: <?php echo e(date('d-m-Y')); ?></span>
                                            </li>

                                            <li>
                                                <h3 class="text" style="font-size: 20px;
                                                font-weight: bold;">
                                                    <span style="font-size: 20px;
                                                    font-weight: bold;">Package Name: </span> <?php echo e($packages->name); ?></h3>
                                            </li>
                                            
                                            <li class="<?php echo e(!($packages->job_post) ? 'd-none' : ''); ?>" >
                                                <h3 class="text">
                                                    <span>Job Post(s): </span> <?php echo e($packages->job_post); ?></h3>
                                            </li>
                                            <li class="<?php echo e(!($packages->featured_type) ? 'd-none' : ''); ?>" >
                                                <h3 class="text">
                                                    <span>Featured Type: </span> <?php echo e($packages->featured_type); ?></h3>
                                            </li>
                                            <li class="<?php echo e(!($packages->featured_amount) ? 'd-none' : ''); ?>" >
                                                <h3 class="text">
                                                    <span>Featured Amount: </span> <?php echo e($packages->featured_amount); ?></h3>
                                            </li>
                                            <li>
                                                <h3 class="text">
                                                    <span>Duration: </span> <?php echo e($packages->duration); ?> Month(s)</h3>
                                            </li>
                                            <li>
                                                <span class="pull-right">price: <?php echo e($packages->price); ?></span>
                                            </li>

                                            <li>
                                                <span class="pull-right">Discount: <?php echo e($packages->discount); ?></span>
                                            </li>

                                            <li>
                                                <span class="pull-right bold">Total: <?php echo e($packages->price - $packages->discount); ?></span>
                                            </li>

                                        </ul>
                                    </div>

                                </div>

                                <div class="col-sm-8 col-sm-offset-1">
                                    <div class="package_details mb50">
                                        <span style="margin-bottom: 10px; display: inline-block;">Payment:</span>
                                        <br>
                                        <form role="form" action="/employer/confirm_package" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($package_type); ?>" name="package_type">
                                            <input type="hidden" value="<?php echo e($packages->id); ?>" name="job_package_id">
                                            <div class="col-lg-12">

                                                <span class="pf-title">Transection Type:</span>
                                                <div class="pf-field">
                                                    <select name="transaction_type" id="transaction_type" autocomplete="off" data-placeholder="Transaction Type" class="chosen">
                                                            <option>Transaction Type</option>
                                                            <option selected value="bkash">Bkash</option>
                                                    </select>
                                                </div>
                                                
                                            
                                                <span class="pf-title">Tranxaction ID:</span>
                                                <div class="pf-field">
                                                    <input type="text" placeholder="ex: TXD15623454" name="txdID" autocomplete="off"> 
                                                </div>
                                                
                                            
                                                <button type="submit" class="post-job-btn pull-right">Submit</button>
                                            </div>
                                            
                                        </form>
                                        
                                        
                                    </div>
                                </div>
					 		</div>
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>