<?php $__env->startSection('title', 'HRBDJobs | Edit Job'); ?>

<?php $__env->startPush('css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(<?php echo e(asset('/images/top-bg.jpg')); ?>) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::guard('employer')->user()->fname.' '. Auth::guard('employer')->user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
							<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column">
				 		<div class="padding-left">
					 		<div class="profile-title">
					 			<h3>Post a New Job</h3>
					 		</div>
					 		<div class="profile-form-edit">
								 <form method="POST" action="<?php echo e(route('employer.new.post.job')); ?>">
									<?php echo csrf_field(); ?>
								 	<input type="hidden" name="job_id" value="<?php echo e($editJob->id); ?>">
					 				<div class="row">
					 					<div class="col-lg-12">
					 						<span class="pf-title">Job Title</span>
					 						<div class="pf-field">
                                                <input type="text" placeholder="Title" name="title" value="<?php echo e($editJob->title); ?>" readonly/>
												<?php if($errors->has('title')): ?>
													<span class="help-block">
														<?php echo e($errors->first('title')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-12">
					 						<span class="pf-title">Description</span>
					 						<div class="pf-field">
												<textarea id="tinymce" name="description" ><?php echo e($editJob->description); ?></textarea>
												<?php if($errors->has('description')): ?>
													<span class="help-block">
														<?php echo e($errors->first('description')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-6">
					 						<span class="pf-title">Job Categories</span>
					 						<div class="pf-field">
					 							<select data-placeholder="Please Select Specialism" class="chosen" name="job_category_id" >
													<option value="">Job Category</option>
													<?php $__currentLoopData = $job_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($job_category->id); ?>" <?php echo e(($editJob->job_category_id == $job_category->id) ? 'selected' : ''); ?>><?php echo e($job_category->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<?php if($errors->has('job_category_id')): ?>
													<span class="help-block">
														<?php echo e($errors->first('job_category_id')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-6">
					 						<span class="pf-title">Job Designation</span>
					 						<div class="pf-field">
					 							<select data-placeholder="Please Select Specialism" class="chosen" name="job_designation_id">
													<option value="">Job Designation</option>
													<?php $__currentLoopData = $job_designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($job_designation->id); ?>"  <?php echo e(($editJob->job_designation_id == $job_designation->id) ? 'selected' : ''); ?>><?php echo e($job_designation->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<?php if($errors->has('job_designation_id')): ?>
													<span class="help-block">
														<?php echo e($errors->first('job_designation_id')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-6">
					 						<span class="pf-title">Job Level</span>
					 						<div class="pf-field">
					 							<select data-placeholder="Please Select Specialism" class="chosen" name="job_level_id">
													<option value="">Job Level</option>
													<?php $__currentLoopData = $job_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($job_level->id); ?>" <?php echo e(($editJob->job_level_id == $job_level->id) ? 'selected' : ''); ?>><?php echo e($job_level->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<?php if($errors->has('job_level_id')): ?>
													<span class="help-block">
														<?php echo e($errors->first('job_level_id')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-6">
					 						<span class="pf-title">Experience</span>
					 						<div class="pf-field">
					 							<select data-placeholder="Please Select Specialism" class="chosen" name="experience_id">
													<option value="">Experience</option>
													<?php $__currentLoopData = $job_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($job_experience->id); ?>" <?php echo e(($editJob->experience_id == $job_experience->id) ? 'selected' : ''); ?>><?php echo e($job_experience->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												<?php if($errors->has('experience_id')): ?>
													<span class="help-block">
														<?php echo e($errors->first('experience_id')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-3">
											<span class="pf-title">Min Salary</span>
											<div class="pf-field">
												<input type="number" placeholder="Min. Salary" name="salary_min" class="salary" value="<?php echo e($editJob->salary_min); ?>"/>
												<?php if($errors->has('salary_min')): ?>
													<span class="help-block">
														<?php echo e($errors->first('salary_min')); ?>

													</span> 
												<?php endif; ?>
											</div>
										</div>
										<div class="col-lg-3">
											<span class="pf-title">Max Salary</span>
											<div class="pf-field">
												<input type="number" placeholder="Max. Salary" name="salary_max" class="salary" value="<?php echo e($editJob->salary_max); ?>"/>
												<?php if($errors->has('salary_max')): ?>
													<span class="help-block">
														<?php echo e($errors->first('salary_max')); ?>

													</span> 
												<?php endif; ?>
											</div>
										</div>

										<div class="col-sm-3">
											<span class="pf-title"></span>
											<div class="pf-field">
												<div class="simple-checkbox">
													<p><input type="checkbox" name="is_negotiable" id="negotiable"  value="<?php if( $editJob ): ?><?php echo e($editJob->is_negotiable); ?><?php else: ?> <?php echo e('1'); ?> <?php endif; ?>"><label for="negotiable">Negotiable</label></p>
													<?php if($errors->has('is_negotiable')): ?>
														<span class="help-block">
															<?php echo e($errors->first('is_negotiable')); ?>

														</span> 
													<?php endif; ?>
												</div>
											</div>
										</div>

										<div class="col-lg-3">
											<span class="pf-title">Vacancy</span>
											<div class="pf-field">
												<input type="number" placeholder="Vacancy" name="vacancy"  value="<?php echo e($editJob->vacancy); ?>"/>
												<?php if($errors->has('vacancy')): ?>
													<span class="help-block">
														<?php echo e($errors->first('vacancy')); ?>

													</span> 
												<?php endif; ?>
											</div>
										</div>

					 					<div class="col-lg-3">
					 						<span class="pf-title">Gender</span>
					 						<div class="pf-field">
					 							<select  class="chosen" name="gender">
													<option value="0" <?php if( $editJob &&  $editJob->gender == 0 ): ?><?php echo e('selected'); ?><?php endif; ?>>All</option>
													<option value="1" <?php if( $editJob &&  $editJob->gender == 1 ): ?><?php echo e('selected'); ?><?php endif; ?>>Male</option>
													<option value="2" <?php if( $editJob &&  $editJob->gender == 2 ): ?><?php echo e('selected'); ?><?php endif; ?>>Female</option>
													<option value="3" <?php if( $editJob &&  $editJob->gender == 3 ): ?><?php echo e('selected'); ?><?php endif; ?>>Others</option>
												</select>
												<?php if($errors->has('gender')): ?>
													<span class="help-block">
														<?php echo e($errors->first('gender')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-6">
					 						<span class="pf-title">Qualification</span>
					 						<div class="pf-field">
												<input type="text" placeholder="Qualification" name="qualification" value="<?php echo e($editJob->qualification); ?>"/>
												<?php if($errors->has('qualification')): ?>
													<span class="help-block">
														<?php echo e($errors->first('qualification')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-3">
					 						<span class="pf-title">Application Deadline Date</span>
					 						<div class="pf-field" id="datepicker">
												<input type="text" class="form-control"  placeholder="2018-05-17" name="deadline"  value="<?php echo e($editJob->deadline); ?>"/>
												<?php if($errors->has('deadline')): ?>
													<span class="help-block">
														<?php echo e($errors->first('deadline')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
					 					<div class="col-lg-12">
					 						<span class="pf-title">Skill Requirments</span>
					 						<div class="pf-field">
												<?php 


													$draftSkills = array();
													if($editJob){
														foreach ($editJob->jobSkill as $draftSkill) {
															$draftSkills[] = $draftSkill->skill;
														}
													}
													
													
												?>
												<select multiple="multiple" class="req-skill"  name="skill[]">
													<option value="">Skill Requirments</option>
													<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($skill->id); ?>"  <?php if(old("skill") && (in_array($skill->id, old("skill")))): ?><?php echo e("selected"); ?><?php elseif( $editJob && in_array($skill->id, $draftSkills )): ?><?php echo e('selected'); ?><?php endif; ?>><?php echo e($skill->name); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
												
												<?php if($errors->has('skill')): ?>
													<span class="help-block">
														<?php echo e($errors->first('skill')); ?>

													</span> 
												<?php endif; ?>
											</div>
					 					</div>
					 					<div class="col-lg-12">
					 						<span class="pf-title">Location</span>
					 						<div class="pf-field">
												<textarea name="location"><?php if(old("location")): ?><?php echo e(old('location')); ?><?php elseif( $editJob ): ?><?php echo e($editJob->location); ?><?php endif; ?></textarea>
												<?php if($errors->has('location')): ?>
													<span class="help-block">
														<?php echo e($errors->first('location')); ?>

													</span> 
												<?php endif; ?>
					 						</div>
					 					</div>
										 <div class="col-lg-12">
											
											<button type="submit" name="post" value="post">Post</button>
										</div>
					 				</div>
					 			</form>
					 		</div>
					 		
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>

<script>
	$(document).ready(function() {
		$('.req-skill').select2({
			placeholder: 'Maximum 5 skills',
			maximumSelectionLength: 5,
			tags: true,
			tokenSeparators: [',', ' '],
  			allowClear: true
		});
	});
</script>


<script>

	tinymce.init({
        selector: "textarea#tinymce",
        theme: "modern",
		branding: false,
        plugins: [
            'advlist autolink lists link image charmap print preview hr anchor pagebreak',
            'searchreplace wordcount visualblocks visualchars code fullscreen',
            'insertdatetime media nonbreaking save table contextmenu directionality',
            'emoticons template paste textcolor colorpicker textpattern imagetools'
        ],
        toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
        toolbar2: 'print preview media | forecolor backcolor emoticons',
        image_advtab: true
    });
    tinymce.suffix = ".min";
    tinyMCE.baseURL = "<?php echo e(asset('js/tinymce/')); ?>";

 </script>

 <script>
	$('input[type="checkbox"][name="is_negotiable"]').on('click', function() {
		if(this.checked) {
			$('.salary').attr('disabled', true);
			$('#negotiable').attr('checked', true);

		}else{
			$('.salary').attr('disabled', false);
			$('#negotiable').attr('checked', false);
		}
	});
 </script>

 <script>
	 $("#datepicker input").datepicker({
		format: 'yyyy-mm-dd',
	 });
 </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>