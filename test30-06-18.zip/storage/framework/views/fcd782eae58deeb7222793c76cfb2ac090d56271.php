


<?php if(session('status')): ?>
    <?php $__env->startPush('js'); ?>

    <script>
        // toastr.success('<?php echo e(session('status')); ?>');
        iziToast.success({
            title: 'Success',
            message: '<?php echo e(session('status')); ?>',
            timeout: 2500,
            overlay: true,
            position: 'topRight',
        });
    </script>

    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php if(session('error')): ?>
    <?php $__env->startPush('js'); ?>

    <script>
        // toastr.error('<?php echo e(session('error')); ?>');
        iziToast.error({
            title: 'Error',
            message: '<?php echo e(session('error')); ?>',
            timeout: 3000,
            overlay: true,
            position: 'topRight',
        });
    </script>

    <?php $__env->stopPush(); ?>
<?php endif; ?>


<?php if(session('errors')): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $__env->startPush('js'); ?>

        <script>
            // var message = "<?php echo e($message); ?>";
            // toastr.error(message);

            iziToast.error({
                title: 'Error',
                message: '<?php echo e($message); ?>',
                timeout: 5000,
                overlay: true,
                position: 'topRight',
            });
        </script>

        <?php $__env->stopPush(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
<?php endif; ?>