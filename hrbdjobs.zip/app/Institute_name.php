<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institute_name extends Model
{
    protected $fillable = [
        'name'
    ];
}
