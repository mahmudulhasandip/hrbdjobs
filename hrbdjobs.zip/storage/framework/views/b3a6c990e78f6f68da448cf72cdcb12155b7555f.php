<?php if(sizeof($candidateCertificate)): ?>
	<form method="post" action="<?php echo e(route('candidate.update.profile.certificate')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col-lg-12">
				<div class="row">
					<?php $__currentLoopData = $candidateCertificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-12">
									<h4 class="text-center">Certificate Summary</h4>
									<hr>
								</div>
								<div class="col-lg-12">
									<span class="pf-title">Certificate Name</span>
									<div class="pf-field">
										<input type="text" name="certification[]" value="<?php echo e($certificate->certification); ?>" required />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Institution Name</span>
									<div class="pf-field">
										<input type="text" name="institution_name[]" value="<?php echo e($certificate->institution_name); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Location</span>
									<div class="pf-field">
										<input type="text" name="location[]" value="<?php echo e($certificate->location); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Start Date</span>
									<div class="pf-field">
										<input type="text" name="start_date[]" class="datepicker" value="<?php echo e($certificate->start_date); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">End Date</span>
									<div class="pf-field">
										<input type="text" name="end_date[]" class="datepicker" value="<?php echo e($certificate->end_date); ?>" />
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-12" id="make_clone_box_certificate">
				
			</div>
			<div class="col-lg-12">
				<a href="javascript:void(0)" onclick="makeBox('certificate')" id="add_certificate" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Certificate</a>
				<button type="submit">Update</button>
			</div>
		</div>
	</form>
<?php else: ?>
<form method="post" action="<?php echo e(route('candidate.update.profile.certificate')); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<div class="row">
		
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="text-center">Certificate Summary</h4>
					<hr>
				</div>
				<div class="col-lg-12">
					<span class="pf-title">Certificate Name</span>
					<div class="pf-field">
						<input type="text" name="certification[]" required />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Institution Name</span>
					<div class="pf-field">
						<input type="text" name="institution_name[]" />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Location</span>
					<div class="pf-field">
						<input type="text" name="location[]" />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Start Date</span>
					<div class="pf-field">
						<input type="text" name="start_date[]" placeholder="01/31/2015" class="datepicker" />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">End Date</span>
					<div class="pf-field">
						<input type="text" name="end_date[]" class="datepicker" />
					</div>
				</div>
			<div class="col-lg-12" id="make_clone_box_certificate">
				
			</div>
		</div>
		<div class="col-lg-12">
			<a href="javascript:void(0)" onclick="makeBox('certificate')" id="add_certificate" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Certificate</a>
			<button type="submit">Update</button>
		</div>
	</div>
</form>
<?php endif; ?>

<div id="make_clone_certificate" class="hidden">
	<div class="row">

		<div class="col-lg-12">
			<h4 class="text-center">Certificate Summary</h4>
			<hr>
		</div>
		<div class="col-lg-12">
			<span class="pf-title">Certificate Name</span>
			<div class="pf-field">
				<input type="text" name="certification[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Institution Name</span>
			<div class="pf-field">
				<input type="text" name="institution_name[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Location</span>
			<div class="pf-field">
				<input type="text" name="location[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Start Date</span>
			<div class="pf-field">
				<input type="text" name="start_date[]" class="datepicker" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">End Date</span>
			<div class="pf-field">
				<input type="text" name="end_date[]" class="datepicker" />
			</div>
		</div>
	</div>
</div>
