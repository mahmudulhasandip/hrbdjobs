<?php $__env->startSection('title', 'HRBDJobs | Candidate Profile'); ?>

<?php $__env->startSection('content'); ?>
    <section class="overlape">
        <div class="block no-padding">
            <div data-velocity="-.1" style="background: url(/images/slider-3.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
            <div class="container fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner-header">
                            <div class="container">
                                <div class="row">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="overlape">
        <div class="block remove-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cand-single-user">
                            <div class="share-bar circle">
                                <a href="<?php echo e(($candidate->linkedin) ? (substr( $candidate->linkedin, 0, 4 ) === "http" ? $candidate->linkedin : 'http://'.$candidate->linkedin) : 'javascript:void(0)'); ?>" target="_blank" class="share-linkedin"><i class="la la-linkedin"></i></a>
                            </div>
                            <div class="can-detail-s">
                                <div class="cst"><img src="<?php echo e(asset('storage/uploads/'.(($candidate->dp) ? $candidate->dp : 'default_user.png'))); ?>" height="145" width="145" /></div>
                                <h3><?php echo e($candidate->fname); ?> <?php echo e($candidate->lname); ?></h3>

                                <?php if(sizeof($candidate->candidateExperience)): ?>
                                    <span><i><?php echo e($candidate->candidateExperience()->first()->jobDesignation->name); ?></i> at <?php echo e($candidate->candidateExperience()->first()->company_name); ?></span>
                                <?php endif; ?>
                                
                                <p><?php echo e($candidate->email); ?></p>
                                <?php if($candidate->phone): ?>
                                <p><?php echo e($candidate->phone); ?></p>
                                <?php endif; ?>
                                <?php if($candidate->website): ?>
                                    <p><a href="<?php echo e(substr( $candidate->website, 0, 4 ) === "http" ? $candidate->website : 'http://'.$candidate->website); ?>" target="_blank"><?php echo e($candidate->website); ?></a></p>
                                <?php endif; ?>
                                 <?php if($candidate->country): ?>
                                    <p><i class="la la-map-marker"></i><?php echo e($candidate->city); ?> / <?php echo e($candidate->country); ?></p>
                                <?php endif; ?>
                            </div>

                            <?php if($candidate->candidateResume()->exists()): ?>
                                <div class="download-cv">
                                    <a href="<?php echo e(asset('storage/uploads/resumes/'.$candidate->candidateResume->resume)); ?>" download="<?php echo e($candidate->candidateResume->resume); ?>">Download CV <i class="la la-download"></i></a>
                                </div>
                            <?php else: ?>
                                <div class="download-cv">
                                    <a href="<?php echo e(route('candidate.resume.view')); ?>">Browse CV <i class="la la-share-square"></i></a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <ul class="cand-extralink">
                            <li><a href="#about" title="">About</a></li>
                            <li><a href="#education" title="">Education</a></li>
                            <li><a href="#experience" title="">Work Experience</a></li>
                            <li><a href="#training" title="">Training</a></li>
                            <li><a href="#certificate" title="">Professional Certificate</a></li>
                        </ul>
                        <div class="cand-details-sec">
                            <div class="row">
                                <div class="col-lg-8 column">
                                    <div class="cand-details" id="about">
                                        <h2>Candidates About</h2>
                                        <p><?php echo e($candidate->about_me); ?></p>
                                        <div class="edu-history-sec" id="education">
                                            <h2>Education</h2>
                                            <?php $__currentLoopData = $candidate->candidateEducation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="edu-history">
                                                <i class="la la-graduation-cap"></i>
                                                <div class="edu-hisinfo">
                                                    <h3><?php echo e($education->level_of_education); ?> - <?php echo e($education->passing_year); ?></h3>
                                                    <i><?php echo e($education->degree_title); ?> - <?php echo e($education->gpa.' out of '.$education->out_of); ?></i> 
                                                    <span><?php echo e($education->institution_name); ?> <i><?php echo e($education->group_majar); ?></i></span>
                                                    <p><?php echo e($education->achievement); ?></p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="edu-history-sec" id="experience">
                                            <h2>Work & Experience</h2>
                                            <?php if(sizeof($candidate->candidateExperience)): ?>
                                                <?php $__currentLoopData = $candidate->candidateExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="edu-history style2">
                                                    <i></i>
                                                    <div class="edu-hisinfo">
                                                        <h3><?php echo e($experience->responsibility); ?> <span><?php echo e($experience->company_name); ?></span> <i>(<?php echo e($experience->company_designation); ?>)</i></h3>
                                                        <i><?php echo e(date("d M, Y", strtotime($experience->start_date))); ?> - <?php echo e(($experience->end_date) ? date("d M, Y", strtotime($experience->end_date)) : 'Continuing'); ?></i>
                                                        <p></p>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="edu-history">
                                                    <i></i>
                                                    <div class="edu-hisinfo">
                                                        <p><i>Fresher</i></p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                        
                                        <?php if(sizeof($candidate->candidateTraining)): ?>
                                        <div class="edu-history-sec" id="training">
                                            <h2>Training</h2>

                                            <?php $__currentLoopData = $candidate->candidateTraining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                                $years = '';
                                                if($training->duration/12) {
                                                    $years = floor($training->duration / 12).' Year';
                                                    $years = $years.($years > 1 ? 's' : '');
                                                    if($years == 0) {
                                                        $years = '';
                                                    }
                                                }
                                                $months = ' '.($training->duration % 12).' Month';
                                                if($months > 1) {
                                                    $months = $months.'s';
                                                }elseif($months  == 0){
                                                    $months = '';
                                                }

                                                $duration = $years.''.$months;
                                            ?>
                                            <div class="edu-history style2">
                                                <i></i>
                                                <div class="edu-hisinfo">
                                                    <h3><?php echo e($training->title); ?></h3>
                                                    <i><?php echo e($training->institution_name); ?>, <?php echo e($training->country); ?></i>
                                                    <i><?php echo e($training->location); ?> - <?php echo e($training->training_year); ?>, <?php echo e($duration); ?></i>
                                                    <p><?php echo e($training->topic_cover); ?></p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(sizeof($candidate->candidateProfessionalCertificate)): ?>
                                        <div class="edu-history-sec" id="certificate">
                                            <h2>Professional Certificate</h2>

                                            <?php $__currentLoopData = $candidate->candidateProfessionalCertificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <div class="edu-history style2">
                                                <i></i>
                                                <div class="edu-hisinfo">
                                                    <h3><?php echo e($certificate->certification); ?></h3>
                                                    <i><?php echo e($certificate->institution_name); ?></i>
                                                    <i><?php echo e(date('d M, Y', strtotime($certificate->start_date))); ?> - <?php echo e(date('d M, Y', strtotime($certificate->end_date))); ?></i>
                                                    <p></p>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if(sizeof($candidate->followEmployer)): ?>
                                        <div class="companyies-fol-sec">
                                            <h2>Companies Followed By</h2>
                                            <div class="cmp-follow">
                                                <div class="row">
                                                    <?php $__currentLoopData = $candidate->followEmployer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-12">
                                                        <a href="<?php echo e(route('public.employer.profile', $follow->employer_id)); ?>" target="_blank"><img src="<?php echo e(( $follow->employer->employerCompanyInfo->logo ) ? asset('storage/uploads/'.$follow->employer->employerCompanyInfo->logo) : asset('storage/uploads/company-avatar.png')); ?>" /><span><?php echo e($follow->employer->employerCompanyInfo->name); ?></span></a>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div> 
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-4 column">
                                    <div class="job-overview">
                                        <h3>Job Overview</h3>
                                        <ul>
                                            <!-- <li><i class="la la-money"></i><h3>Offerd Salary</h3><span>£15,000 - £20,000</span></li> -->
                                            <li><i class="la la-mars-double"></i><h3>Gender</h3><span><?php echo e($candidate->gender); ?></span></li>
                                            <li><i class="la la-thumb-tack"></i><h3>Career Level</h3><span><?php echo e($candidate->candidateSkill->first()->jobLevel->name); ?></span></li>
                                            <li><i class="la la-puzzle-piece"></i><h3>Industry</h3><span><?php echo e($candidate->candidateSkill->first()->jobCategory->name); ?></span></li>
                                            <li><i class="la la-bomb"></i><h3>Designation</h3><span><?php echo e($candidate->candidateSkill->first()->jobDesignation->name); ?></span></li>
                                            <li><i class="la la-shield"></i><h3>Experience</h3><span><?php echo e($candidate->candidateSkill->first()->experience); ?> Years</span></li>
                                            <?php if(sizeof($candidate->candidateEducation)): ?>
                                            <li><i class="la la-graduation-cap "></i><h3>Qualification</h3><span><?php echo e($candidate->candidateEducation[sizeof($candidate->candidateEducation)-1]->degree_title); ?></span></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div><!-- Job Overview -->
                                    <div class="job-overview">
                                        <h3>Skill's of candidates</h3>

                                        <div class="skills">
                                            <?php if(sizeof($candidate->candidateSkill)): ?>
                                                <?php $__currentLoopData = $candidate->candidateSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $can_skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><?php echo e($can_skill->skill->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('users.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>