 
<?php $__env->startSection('title', 'HRBDJobs | Employer Shortlisted Candidate'); ?> 
<?php $__env->startSection('content'); ?>
<section class="overlape">
	<div class="block no-padding">
		<div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
		<!-- PARALLAX BACKGROUND IMAGE -->
		<div class="container fluid">
			<div class="row">
				<div class="col-lg-12">
					<div class="inner-header">
						<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="block no-padding">
		<div class="container">
			<div class="row no-gape">
				<aside class="col-lg-3 column border-right">
					<div class="widget">
					<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>

				</aside>
				<div class="col-lg-9 column mb-50">
					<div class="padding-left">
						<div class="emply-resume-sec">
							<!-- Tags Bar -->
							<div class="filterbar mt-50">
								<div class="sortby-sec">
									<span>Sort by</span>
									<select class="left filter location" >
										<option value="">Location</option>
										<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<option value="<?php echo e(ucfirst(trans($location->city))); ?>"><?php echo e(ucfirst(trans($location->city))); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<select class="left filter institution">
										<option value="">Institution</option>
										<?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($institute->institution_name); ?>"><?php echo e($institute->institution_name); ?></>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<select class="left filter experience">
										<option value="">Experience</option>
										<?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($experience->name); ?>"><?php echo e($experience->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>

							<h3>Applied Candidate's</h3>
							<input type="hidden" value="<?php echo e($job_id); ?>" id="job_id">

							
							<div class="candidate_list">
								
								<?php echo $__env->make('employer.ajaxPartials.applied_candidates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>

							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" />
<style>
	.nice-select{
		clear: none;
		margin-right: 5px;
	}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
<script>
	$(document).ready(function() {
		$('select').niceSelect();
	});
</script>
<script>
	var base_url = "<?php echo e(url('/employer/')); ?>";
    $('.shortListCandidate').click(function() {
        var candidateId = $(this).data('candidateid');
		var jobId = $(this).data('jobid');
        if($(this).hasClass('unshortlisted')){
			$(this).removeClass().addClass('shortlisted');
            $(this).html('Remove from Shortlist');
        }else if($(this).hasClass('shortlisted')){
			$(this).removeClass().addClass('unshortlisted');
			$(this).html('Add To Shortlist');
        }
        $.ajax({
            url: base_url+"/job/candidates/applied/shortListed/",
            type: "post",
            headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
            data:{candidate_id: candidateId, job_id: jobId},
            success: function(message){
                iziToast.success({
                    title: message,
                    timeout: 2000,
                    overlay: true,
                    position: 'topRight',
                });

            
            }
        });
        
    });

	$('.reject_candidate').click(function() {
        var candidateId = $(this).data('candidateid');
		var jobId = $(this).data('jobid');
        $.ajax({
            url: base_url+"/job/candidates/applied/reject/",
            type: "post",
            headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
            data:{candidate_id: candidateId, job_id: jobId},
            success: function(message){
                iziToast.error({
                    title: message,
                    timeout: 2000,
                    overlay: true,
                    position: 'topRight',
                });

            
            }
        });
        
    });

</script>


<script>

	$(document).ready(function(){
		$(document).on('click', '.pagination .page-link',function(event){
			event.preventDefault();
			var myurl = $(this).attr('href');
			getData(myurl);
		});
	});

	function getData(myurl){
		var location = $('.filter.location').val();
		var institution = $('.filter.institution').val();
		var experience = $('.filter.experience').val();
		var job_id = $('#job_id').val();


		$.ajax({
			url: myurl,
			type: "get",
			headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
			data: {location: location, institution: institution, experience: experience, job_id: job_id},
			datatype: "html"
		}).done(function(data){
			$(".candidate_list").empty().html(data);
			window.history.pushState('','', myurl);
		}).fail(function(jqXHR, ajaxOptions, thrownError){
			alert('No response from server');
		});
	}

</script>


<script>
	var base_url = "<?php echo e(url('/employer/')); ?>";
	
	$(document).ready(function(){
		$(document).on('change', '.filter', function(event){
			event.preventDefault();
			$location = $('.filter.location').val();
			$institution = $('.filter.institution').val();
			$experience = $('.filter.experience').val();
			var job_id = $('#job_id').val();
			$.ajax({
				url: base_url+'/job/candidates/applied/'+job_id,
				type: "post",
				headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
				data: {location: $location, institution: $institution, experience: $experience, job_id: job_id},
				datatype: "html"
			}).done(function(data){
				$(".candidate_list").empty().html(data);
			}).fail(function(jqXHR, ajaxOptions, thrownError){
				alert('No response from server');
			});
		});
	});
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>