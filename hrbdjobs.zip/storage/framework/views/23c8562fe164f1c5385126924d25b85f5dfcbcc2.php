<?php $__env->startSection('title', 'HRHRBDobs | Candidate Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="overlape">
        <div class="block no-padding">
            <div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
            <div class="container fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner-header">
                            <h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="block no-padding">
            <div class="container">
                 <div class="row no-gape">
                    <aside class="col-lg-3 column border-right">
                        <div class="widget" id="sidebar">
                            <?php echo $__env->make('candidate.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        
                    </aside>
                    <div class="col-lg-9 column">
                        <div class="padding-left">
                            <div class="manage-jobs-sec">
                                <div class="border-title"><h3>My Resume</h3></div>
                                    <section>
                                        <div class="block p0">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="tab-sec">
                                                            
                                                            <div class="download-cv mb-65">
                                                                <?php if($candidate->candidateResume): ?>
                                                                <a class="ml-10" href="<?php echo e(route('candidate.uploaded.resume.view')); ?>" target="_blank" title="">Uploaded Resume <i class="la la-download"></i></a>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(route('candidate.download.resume', $candidate->id)); ?>" id="download-resume"  title="">Generate Resume <i class="la la-download"></i></a>
                                                            </div>
                                                            <div id="resume">	
        	
                                                                <table border="0" cellpadding="0" cellspacing="0" align="center" width="700">
                                                                
                                                            
                                                                        <tbody><tr>
                                                                        <td colspan="6">
                                                                        <table border="0" align="center" cellpadding="0" cellspacing="0" width="100%">
                                                                            <tbody><tr>
                                                                            <td width="73%" height="" align="left"  class="HRBDApplicantsName">
                                                                            <table>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td>
                                                                                        <!--Contact Address:-->
                                                                                            <!--Applicant's Name:-->
                                                                                            <?php echo e($candidate->fname.' '.$candidate->lname); ?>

                                                                                            <?php if($candidate->current_address): ?>
                                                                                            <br>
                                                                                            <span>
                                                                                               <i class="la la-map-marker"></i> Address: <?php echo e($candidate->current_address); ?>

                                                                                            </span>       
                                                                                            <?php endif; ?>

                                                                                            <?php if($candidate->phone): ?>
                                                                                            <!--Home Phone:-->
                                                                                            <br>
                                                                                            <span>
                                                                                                <i class="la la-phone"></i> Phone: <?php echo e($candidate->phone); ?>    
                                                                                                <!--Office Phone:-->
                                                                                                <!--Mobile:-->
                                                                                            </span>
                                                                                            <?php endif; ?>
                                                                                            <br>       
                                                                                            <span>
                                                                                               <i class="la la-envelope-o"></i> e-mail: <a href="mailto:<?php echo e($candidate->email); ?>"><?php echo e($candidate->email); ?></a>
                                                                                            </span>
                                                                                            <?php if($candidate->linkedin): ?>
                                                                                            <!--Home Phone:-->
                                                                                            <br>
                                                                                            <span>
                                                                                                <i class="la la-linkedin"></i> Linkedin: <a href="<?php echo e(substr( $candidate->linkedin, 0, 4)  === 'http' ? $candidate->linkedin : 'http://'.$candidate->linkedin); ?>" target="_blank"><?php echo e($candidate->linkedin); ?></a>   
                                                                                                <!--Office Phone:-->
                                                                                                <!--Mobile:-->
                                                                                            </span>
                                                                                            <?php endif; ?>
                                                                                        </td>
                                                                            </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            
                                                                            </td>
                                                                            
                                                                            <td width="27%" rowspan="2" align="right" valign="bottom">
                                                                            <!--Photograph:-->
                                                                            
                                                                                <table width="140" height="140" border="0" align="center" cellpadding="0" cellspacing="7" bgcolor="#dadce1">
                                                                                    <tbody><tr> 
                                                                                    <td width="126" height="135" align="center" bgcolor="#e2e4e5" valign="middle"> 
                                                                                    <img src="<?php echo e(asset('storage/uploads/'.(($candidate->dp) ? $candidate->dp : 'default_user.png'))); ?>" width="124" height="135">
                                                                                    </td>
                                                                                    </tr>
                                                                                </tbody></table>
                                                                            
                                                                            </td>
                                                                            </tr>
                                                                        </tbody></table>
                                                                        </td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                    
                                                                <!---------------
                                                                CAREER OBJECTIVE:
                                                                ----------------->
                                                                <?php if($candidate->about_me): ?>
                                                                    <table border="0" cellpadding="0" cellspacing="0" align="center" width="700">	
                                                                        <tbody><tr>
                                                                             <td colspan="6" style="border-bottom:1px solid #000000;">&nbsp;</td>
                                                                             </tr>
                                                                              
                                                                             <tr><td colspan="6">&nbsp;</td></tr>		 
                                                                             
                                                                             <tr>
                                                                             <td colspan="6" class="HRBDHeadline01"><u>Career Objective:</u></td>
                                                                             </tr>
                                                                             
                                                                             <tr>
                                                                             <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                             <?php echo e($candidate->about_me); ?>	
                                                                             </td>
                                                                             </tr>		
                                                                        </tbody>
                                                                    </table>
                                                                <?php endif; ?>
                                                                <!--------------
                                                                CAREER SUMMARY :
                                                                ---------------->
                                                                
                                                                <!---------------------
                                                                SPECIAL QUALIFICATION :
                                                                ----------------------->
                                                                         
                                                                <!-------------------------------------------
                                                                EMPLOYMENT HISTORY, TOTAL YEAR OF EXPERIENCE:
                                                                --------------------------------------------->
                                                                <?php if(sizeof($candidate->candidateExperience)): ?>
                                                                    <table border="0" cellpadding="0" style="margin-top:3px;" cellspacing="0" align="center" width="700">
                                                                           <!--
                                                                           Employment History:
                                                                           -->
                                                                          <tbody><tr>
                                                                          <td colspan="6" class="HRBDHeadline01"><u>Employment History:</u></td>
                                                                          </tr>
                                                                          <!--Total Year of Experience:-->
                                                                          
                                                                               <tr>
                                                                                    <?php if(sizeof($candidate->candidateSkill)): ?>
                                                                                        <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                                            <strong>Total Year of Experience :</strong> <?php echo e($candidate->candidateSkill->first()->experience); ?> Year(s)
                                                                                        </td>
                                                                                    <?php else: ?>
                                                                                        <?php
                                                                                            $days = 0;
                                                                                            foreach($candidate->candidateExperience as $experience){
                                                                                                if($experience->end_date){
                                                                                                    $datetime1 = new DateTime(date("Y-m-d", strtotime($experience->start_date)));
                                                                                                    $datetime2 = new DateTime(date("Y-m-d", strtotime($experience->end_date)));
                                                                                                    $interval = $datetime1->diff($datetime2);
                                                                                                    $days += $interval->format('%R%a');
                                                                                                }else{
                                                                                                    $datetime1 = new DateTime(date("Y-m-d", strtotime($experience->start_date)));
                                                                                                    $datetime2 = new DateTime(date("Y-m-d"));
                                                                                                    $interval = $datetime1->diff($datetime2);
                                                                                                    $days += $interval->format('%a');
                                                                                                }
                                                                                            }
                                                                                            
                                                                                        ?>
                                                                                        <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                                            <?php 
                                                                                                $months = round($days / 30);
                                                                                                $years = 0;
                                                                                                if($months >= 12){
                                                                                                    $years = floor($months / 12);
                                                                                                    $months = $months % 12;
                                                                                                }

                                                                                                if($years == 1){
                                                                                                    $years = $years . ' Year';
                                                                                                }else if($years == 0){
                                                                                                    $years = '';
                                                                                                }else{
                                                                                                    $years = $years.' Years';
                                                                                                }

                                                                                                if($months == 1){
                                                                                                    $months = $months . ' Month';
                                                                                                }else if($months == 0){
                                                                                                    $months = '';
                                                                                                }else{
                                                                                                    $months = $months.' Months';
                                                                                                }
                                                                                            ?>
                                                                                            <strong>Total Year of Experience :</strong> <?php echo e($years.' '. $months); ?>

                                                                                        </td>
                                                                                    <?php endif; ?>
                                                                               </tr>
                                                                            <?php if(sizeof($candidate->candidateExperience)): ?>
                                                                                <?php 
                                                                                    $id = 1;
                                                                                ?>
                                                                                <?php $__currentLoopData = $candidate->candidateExperience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <tr>
                                                                                         <td width="22" align="center" style="padding-left:5px;" class="HRBDNormalText01"><?php echo e($id++); ?>.</td>
                                                                                         <td width="700" colspan="5" align="left" class="HRBDBoldText01">
                                                                                         <!--Position, DateFrom, DateTo:-->					 
                                                                                         <u><?php echo e($experience->jobDesignation->name); ?> ( <?php echo e(date('d M, Y', strtotime($experience->start_date))); ?> - <?php echo e(($experience->end_date) ?  date('d M, Y', strtotime($experience->end_date)) : 'Continuing'); ?>)</u></td>
                                                                                    </tr>	
                                                                
                                                                                    <tr>
                                                                                        <td align="center" class="HRBDHeadline02">&nbsp;</td>
                                                                                        <td colspan="5" align="left" class="HRBDNormalText01">
                                                                                            <!--Company Name:-->
                                                                                            <strong><?php echo e($experience->company_name); ?></strong>
                                                                                            <br>
                                                                                            <!--Department:-->
                                                                                            Department: <?php echo e($experience->company_designation); ?>

                                                                                            <br>
                                                                                            <!--Area of Experience :-->
                                                                                            <!--IMPLEMENT LATER<br />-->
                                                                                         
                                                                                            <!--Duties/Responsibilities:-->
                                                                                         
                                                                                            <strong><i><u>Duties/Responsibilities:</u></i></strong>
                                                                                            <br>
                                                                                            <?php echo e($experience->responsibility); ?>	  
                                                                                         </td>
                                                                                    </tr>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                    </tbody>
                                                                </table>
                                                                <?php endif; ?>        
                                                                <!----------------------
                                                                'ACADEMIC QUALIFICATION:
                                                                ------------------------>
                                                                <?php if(sizeof($candidate->candidateEducation)): ?>
                                                                     <table border="0" cellpadding="0" style="margin-top:3px;" cellspacing="0" align="center" width="700">
                                                                          <tbody><tr>
                                                                         <td colspan="6" class="HRBDHeadline01"><u>Academic Qualification:</u></td>
                                                                         </tr>
                                                                    
                                                                         <tr>
                                                                         <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                         <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" style="border:1px solid #666666">
                                                                                <tbody>
                                                                                    <tr class="HRBDNormalText02">
                                                                                        <td width="25%" class="border-right-ash"><strong>Exam Title</strong></td>
                                                                                        <td width="25%" class="border-right-ash"><strong>Concentration/Major</strong></td>
                                                                                        <td width="25%" class="border-right-ash"><strong>Institute</strong></td>
                                                                                        <td width="12.5%" class="border-right-ash"><strong>Result</strong></td>
                                                                                        <td width="12.5%"><strong>Pas.Year</strong></td>
                                                                                    </tr>			 
                                                                                    <?php $__currentLoopData = $candidate->candidateEducation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <tr class="HRBDNormalText02">
                                                                                    <!--Exam Title:-->
                                                                                        <td width="25%" class="border-right-ash border-top-ash">
                                                                                            <?php echo e($education->level_of_education); ?>

                                                                                        </td>
                                                                                        <!--Concentration/Major:-->
                                                                                        <td width="25%" class="border-right-ash border-top-ash">
                                                                                            <?php echo e($education->degree_title); ?>

                                                                                        </td>
                                                                                        <!--Institute:-->
                                                                                        <td width="25%" class="border-right-ash border-top-ash">
                                                                                            <?php echo e($education->institution_name); ?>

                                                                                        </td>
                                                                                        <!--Result:-->
                                                                                        <td width="12.5%" class="border-right-ash border-top-ash">CGPA:<?php echo e($education->gpa); ?><br>out of <?php echo e($education->out_of); ?>

                                                                                        </td>
                                                                                        <!--Passing Year:-->
                                                                                        <td width="12.5%" class="border-top-ash">
                                                                                            <?php echo e(($education->passing_year) ? $education->passing_year : '-'); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </tbody>
                                                                                </table> 
                                                                         </td>
                                                                         </tr>
                                                                     </tbody></table>
                                                                <?php endif; ?>
                                                                
                                                                <?php if(sizeof($candidate->candidateTraining)): ?>
                                                                <table border="0" cellpadding="0" style="margin-top:3px;" cellspacing="0" align="center" width="700">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td colspan="6" class="HRBDHeadline01"><u>Training:</u></td>
                                                                        </tr>
                                                                    
                                                                        <tr>
                                                                            <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                                <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" style="border:1px solid #666666">
                                                                                    <tbody>
                                                                                        <tr class="HRBDNormalText02">
                                                                                            <td width="25%" class="border-right-ash"><strong>Training Title</strong></td>
                                                                                            <td width="25%" class="border-right-ash"><strong>Topic</strong></td>
                                                                                            <td width="12.5%" class="border-right-ash"><strong>Institute</strong></td>
                                                                                            <td width="12.5%" class="border-right-ash"><strong>Location</strong></td>
                                                                                            <td width="12.5%" class="border-right-ash"><strong>Year</strong></td>
                                                                                            <td width="12.5%"><strong>Duration</strong></td>
                                                                                        </tr>            
                                                                                        <?php $__currentLoopData = $candidate->candidateTraining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <tr class="HRBDNormalText02">
                                                                                        <!--Exam Title:-->
                                                                                            <td width="25%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($training->title); ?>

                                                                                            </td>
                                                                                            <!--Concentration/Major:-->
                                                                                            <td width="25%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($training->topic_cover); ?>

                                                                                            </td>
                                                                                            <!--Institute:-->
                                                                                            <td width="12.5%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($training->institution_name); ?>

                                                                                            </td>
                                                                                            <!--Result:-->
                                                                                            <td width="12.5%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($training->location); ?>, <?php echo e($training->country); ?>

                                                                                            </td>
                                                                                            <!--Passing Year:-->
                                                                                            <td width="12.5%" class="border-right-ash border-top-ash">  
                                                                                                <?php echo e($training->training_year); ?>

                                                                                            </td>

                                                                                            <!--Duration:-->
                                                                                            <td width="12.5%" class="border-top-ash">  
                                                                                                <?php echo e($training->duration); ?>

                                                                                            </td>
                                                                                        </tr>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </tbody>
                                                                                </table> 
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <?php endif; ?>
                                                                <!--------------------------
                                                                PROFESSIONAL QUALIFICATION:
                                                                --------------------------->
                                                                <?php if(sizeof($candidate->candidateProfessionalCertificate)): ?>
                                                                <table border="0" cellpadding="0" style="margin-top:3px;" cellspacing="0" align="center" width="700">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td colspan="6" class="HRBDHeadline01"><u>Professional Certificate:</u></td>
                                                                        </tr>
                                                                    
                                                                        <tr>
                                                                            <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                                <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" style="border:1px solid #666666">
                                                                                    <tbody>
                                                                                        <tr class="HRBDNormalText02">
                                                                                            <td width="25%" class="border-right-ash"><strong>Certificate Title</strong></td>
                                                                                            <td width="25%" class="border-right-ash"><strong>Institute</strong></td>
                                                                                            <td width="25%" class="border-right-ash"><strong>Location</strong></td>
                                                                                            <td width="12.5%" class="border-right-ash"><strong>Start Date</strong></td>
                                                                                            <td width="12.5%"><strong>End Date</strong></td>
                                                                                        </tr>            
                                                                                        <?php $__currentLoopData = $candidate->candidateProfessionalCertificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <tr class="HRBDNormalText02">
                                                                                        <!--Exam Title:-->
                                                                                            <td width="25%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($certificate->certification); ?>

                                                                                            </td>
                                                                                            <!--Institute:-->
                                                                                            <td width="25%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($certificate->institution_name); ?>

                                                                                            </td>
                                                                                            <!--Result:-->
                                                                                            <td width="25%" class="border-right-ash border-top-ash">
                                                                                                <?php echo e($certificate->location); ?>

                                                                                            </td>
                                                                                            <!--Passing Year:-->
                                                                                            <td width="12.5%" class="border-right-ash border-top-ash">  
                                                                                                <?php echo e(date('d M, Y', strtotime($certificate->start_date))); ?>

                                                                                            </td>

                                                                                            <!--Duration:-->
                                                                                            <td width="12.5%" class="border-top-ash">  
                                                                                                <?php echo e(date('d M, Y', strtotime($certificate->end_date))); ?>

                                                                                            </td>
                                                                                        </tr>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </tbody>
                                                                                </table> 
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                                <?php endif; ?>
                                                                    
                                                                <!---------------------------------
                                                                CAREER AND APPLICATION INFORMATION:
                                                                ----------------------------------->
                                                                    <table border="0" cellpadding="0" cellspacing="0" align="center" width="700" style="margin-top:3px;">
                                                                        <!--
                                                                        Career and Application Information:
                                                                        -->
                                                                        <tbody><tr>
                                                                        <td colspan="6" class="HRBDHeadline01"><u>Career and Application Information:</u></td>
                                                                        </tr>
                                                                    
                                                                        <tr>
                                                                        <td colspan="6" align="left" class="HRBDNormalText01">
                                                                        <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%">
                                                                            <!--Looking For:-->
                                                                            
                                                                                <tbody>
                                                                                    <?php if(sizeof($candidate->candidateSkill)): ?>
                                                                                    <tr class="HRBDNormalText03">
                                                                                        <td width="35%" align="left" style="padding-left:5px;">Looking For</td>
                                                                                        <td width="2%" align="center">:</td>
                                                                                        <td width="63%" align="left">
                                                                                            <?php if($candidate->candidateSkill->first()->experience >= 1 && $candidate->candidateSkill->first()->experience <= 3): ?>
                                                                                                Mid Level Job
                                                                                            <?php elseif($candidate->candidateSkill->first()->experience >= 4): ?>
                                                                                                Expert Level Job
                                                                                            <?php else: ?>
                                                                                                Fresher Level Job
                                                                                            <?php endif; ?>
                                                                                        </td>
                                                                                    </tr>
                                                                            
                                                                                    <!--Available For:-->
                                                                                    <tr class="HRBDNormalText03">
                                                                                        <td width="35%" align="left" style="padding-left:5px;">Available  For</td>

                                                                                        <td width="2%" align="center">:</td>
                                                                                        <td width="63%" align="left">
                                                                                            <?php echo e($candidate->candidateSkill->first()->jobLevel->name); ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                <?php endif; ?>
                                                                            <?php if($candidate->candidateSkill): ?>
                                                                                <!--Preferred Job Category:-->
                                                                                <tr class="HRBDNormalText03">
                                                                                    <td width="35%" align="left" style="padding-left:5px;">Preferred  Job Category</td>
                                                                                    <td width="2%" align="center">:</td>
                                                                                    <td width="63%" align="left">
                                                                                        <?php echo e($candidate->candidateSkill->first()->jobCategory->name); ?>

                                                                                    </td>
                                                                                </tr>

                                                                                <!--Preferred Job Category:-->
                                                                                <tr class="HRBDNormalText03">
                                                                                    <td width="35%" align="left" style="padding-left:5px;">Preferred  Job Designation</td>
                                                                                    <td width="2%" align="center">:</td>
                                                                                    <td width="63%" align="left">
                                                                                        <?php echo e($candidate->candidateSkill->first()->jobDesignation->name); ?>

                                                                                    </td>
                                                                                </tr>
                                                                            <?php endif; ?>
                                                                            
                                                                            <!--Preferred District:-->
                                                                            
                                                                            <tr class="HRBDNormalText03">
                                                                            <td width="35%" align="left" style="padding-left:5px;">Preferred  District </td>
                                                                            <td width="2%" align="center">:</td>
                                                                            <td width="63%" align="left">
                                                                                <?php echo e(($candidate->city) ? $candidate->city : 'Anywhere'); ?>        
                                                                            </td>
                                                                            </tr>
                                                                             
                                                                            <!--Preferred Country:-->
                                                                                    
                                                                            <tr class="HRBDNormalText03">
                                                                            <td width="35%" align="left" style="padding-left:5px;">Preferred  Country </td>
                                                                            <td width="2%" align="center">:</td>
                                                                            <td width="63%" align="left">
                                                                                <?php echo e(($candidate->country) ? $candidate->country : 'Anywhere'); ?>        
                                                                            </td>
                                                                            </tr>
                                                                            
                                                                        </tbody></table>
                                                                        </td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                
                                                                
                                                                <!--
                                                                Specialization:
                                                                -->
                                                                
                                                                
                                                                     <table border="0" cellpadding="0" cellspacing="0" align="center" width="700" style="margin-top:3px;">
                                                                         <tbody><tr>
                                                                        <td colspan="6" class="HRBDHeadline01"><u>Specialization:</u></td>
                                                                        </tr>
                                                                                 
                                                                               <tr>
                                                                             <td colspan="6" align="left" style="padding-left:5px;" class="HRBDNormalText01">
                                                                             <table border="0" cellpadding="0" cellspacing="0" align="center" width="700" style="border:1px solid #666666">
                                                                                <tbody><tr>
                                                                                
                                                                                     <td width="40%" class="HRBDNormalText02" style="border-right:1px solid #666666;border-bottom:1px solid #666666;">
                                                                                     <strong>Fields of Specialization</strong>
                                                                                     </td>
                                                                                    
                                                                                  </td>
                                                                               </tr>
                                                                                
                                                                                <tr>
                                                                                
                                                                                    <td align="left" class="HRBDNormalText03" style="border-right:1px solid #666666;">

                                                                                        <div class="skill">
                                                                                            <?php $__currentLoopData = $candidate->candidateSkill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $can_skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <span><?php echo e($can_skill->skill->name); ?></span>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </ul>
                                                                                    </td>
                                                                                </tr>		
                                                                             </tbody></table>	
                                                                             </td>
                                                                             </tr>
                                                                        
                                                                </tbody></table>
                                                                
                                                                <!--
                                                                PERSONAL DETAILS:
                                                                -->
                                                                
                                                                     <table border="0" cellpadding="0" cellspacing="0" align="center" width="700" style="margin-top:3px;">
                                                                        <!--
                                                                        Personal Details
                                                                        -->
                                                                        <tbody><tr>
                                                                        <td colspan="6" class="HRBDHeadline01"><u>Personal Details :</u></td>
                                                                        </tr>
                                                                    
                                                                        <tr>
                                                                        <td colspan="6" align="left" class="HRBDNormalText01">
                                                                        <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%">
                                                                            <!--Fathers Name:-->
                                                                            
                                                                                 <tbody><tr class="HRBDNormalText03">
                                                                                 <td width="22%" align="left" style="padding-left:5px;">Father's Name </td>
                                                                                 <td width="2%" align="center">:</td>
                                                                                 <td width="76%" align="left">
                                                                                    <?php echo e($candidate->father_name); ?>

                                                                                 </td>
                                                                                 </tr>
                                                                            
                                                                            <!--Mothers Name:-->
                                                                            
                                                                                 <tr class="HRBDNormalText03">
                                                                                 <td width="22%" align="left" style="padding-left:5px;">Mother's Name </td>
                                                                                 <td width="2%" align="center">:</td>
                                                                                 <td width="76%" align="left">
                                                                                 <?php echo e($candidate->mother_name); ?>

                                                                                 </td>
                                                                                 </tr>
                                                                            
                                                                            <!--Date of Birth:-->
                                                                            <tr class="HRBDNormalText03">
                                                                            <td width="22%" align="left" style="padding-left:5px;">Date  of Birth</td>
                                                                            <td width="2%" align="center">:</td>
                                                                            <td width="76%" align="left">
                                                                                <?php echo e(date('d M, Y', strtotime($candidate->father_name))); ?>	 
                                                                            </td>
                                                                            </tr>
                                                                            <!--Gender:-->
                                                                            <tr class="HRBDNormalText03">
                                                                            <td width="22%" align="left" style="padding-left:5px;">Gender</td>
                                                                            <td width="2%" align="center">:</td>
                                                                            <td width="76%" align="left">
                                                                                <?php echo e($candidate->gender); ?>

                                                                            </td>
                                                                            </tr>
                                                                            <!--Marital Status:-->
                                                                            <tr class="HRBDNormalText03">
                                                                            <td width="22%" align="left" style="padding-left:5px;">Marital  Status </td>
                                                                            <td width="2%" align="center">:</td>
                                                                            <td width="76%" align="left">
                                                                            <?php echo e($candidate->marital_status); ?>

                                                                            </td>
                                                                            </tr>
                                                                            <!--Nationality:-->
                                                                            <tr class="HRBDNormalText03">
                                                                            <td align="left" style="padding-left:5px;">Nationality</td>
                                                                            <td align="center">:</td>
                                                                            <td align="left">
                                                                            <?php echo e($candidate->nationality); ?>

                                                                            </td>
                                                                            </tr>
                                                                            
                                                                            <tr class="HRBDNormalText03">
                                                                            <td align="left" style="padding-left:5px;">National Id No.</td>
                                                                            <td align="center">:</td>
                                                                            <td align="left">
                                                                            <?php echo e($candidate->nid_passport); ?>

                                                                            </td>
                                                                            </tr>
                                                                            
                                                                            
                                                                            <!--Permanent Address:-->
                                                                            
                                                                                 <tr class="HRBDNormalText03">
                                                                                 <td align="left" style="padding-left:5px;">Permanent  Address</td>
                                                                                 <td align="center">:</td>
                                                                                 <td align="left">
                                                                                    <?php echo e($candidate->permanent_address); ?>

                                                                                 </td>
                                                                                 </tr>
                                                                            
                                                                            <!--Current Location:-->
                                                                            <tr class="HRBDNormalText03">
                                                                            <td align="left" style="padding-left:5px;">Current  Location</td>
                                                                            <td align="center">:</td>
                                                                            <td align="left">			
                                                                            <?php echo e($candidate->current_address); ?>

                                                                            </td>
                                                                            </tr>
                                                                        </tbody></table>
                                                                        </td>
                                                                        </tr>
                                                                    </tbody></table>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>  
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

    <script>
       
        
    </script>
    
<?php $__env->stopPush(); ?>




<?php echo $__env->make('candidate.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>