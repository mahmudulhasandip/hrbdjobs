<?php $__currentLoopData = $applied_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="emply-resume-list">
    <div class="emply-resume-thumb">
        <img src="<?php echo e(asset('storage/uploads/'. (($job->candidate->dp) ? $job->candidate->dp : 'default_user.png'))); ?>" alt="Photo" />
    </div>
    
    <div class="emply-resume-info">
        <h3>
            <a href="<?php echo e(route('employer.public.candidate.resume', $job->candidate->id)); ?>" target="_blank" title=""><?php echo e($job->candidate->fname); ?> <?php echo e($job->candidate->lname); ?> <span class="text-blue">(Age: <?php echo e(date_diff(date_create(date('Y-m-d', strtotime($job->candidate->date_of_birth))), date_create(date('Y-m-d')))->format("%y years")); ?>)</span></a>
        </h3>
        <span>
            
            <i><?php echo e($job->candidate->candidateEducation->first()['institution_name']); ?></i>
        </span>
        <p>
            <i class="la la-phone"></i><?php echo e($job->candidate->phone); ?>

        </p>
        <p>
            <i class="la la-briefcase"></i><?php echo e($job->candidate->candidateSkill->first()['experience']); ?> Year<?php echo e(($job->candidate->candidateSkill->first()['experience'] > 1) ? 's' : ''); ?>

        </p>
    </div>
    <div class="action-resume">
        <div class="action-center">
            <span>Action
                <i class="la la-angle-down"></i>
            </span>
            <ul>
                <li>
                    <a href="<?php echo e(route('employer.public.candidate.resume', $job->candidate->id)); ?>" target="_blank" title="">View CV</a>
                </li>
                <li>
                    <a href="<?php echo e(route('public.candidate.profile', $job->candidate->id)); ?>" target="_blank" title="">View Profile</a>
                </li>
                <li>
                <?php if($job->is_short_listed): ?>
                <a href="javascript: ;" class="shortListCandidate shortlisted" data-jobId="<?php echo e($job->job_id); ?>" data-candidateId="<?php echo e($job->candidate_id); ?>" title="">Remove from Shortlist</a>
                <?php else: ?>
                <a href="javascript: ;" class="shortListCandidate unshortlisted" data-jobId="<?php echo e($job->job_id); ?>" data-candidateId="<?php echo e($job->candidate_id); ?>" title="">Add To Shortlist</a>
                <?php endif; ?>
                </li>
            </ul>
        </div>
    </div>
    <div class="del-resume">
        <a href="javascript;" class="reject_candidate" data-jobId="<?php echo e($job->job_id); ?>" data-candidateId="<?php echo e($job->candidate_id); ?>" title="Reject Candidate">
            <i class="la la-times text-red"></i>
        </a>
    </div>
</div>
<!-- Emply List -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="pagination-laravel">
    <?php echo e($applied_jobs->appends($_GET)->links()); ?>

</div>