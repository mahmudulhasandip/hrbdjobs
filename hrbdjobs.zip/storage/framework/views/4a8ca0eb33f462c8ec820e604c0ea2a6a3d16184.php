	<div class="job-listing wtabs">
		<div class="job-title-sec pointer newtab" data-url="<?php echo e(route('single.job', $job->id)); ?>">
			<div class="c-logo"> <img src="<?php echo e(asset('storage/uploads/'.(($job->employer->employerCompanyInfo['logo']) ? $job->employer->employerCompanyInfo['logo'] : 'default_user.png'))); ?>" alt="" /> </div>
			<h3><a href="#" title=""><?php echo e($job->title); ?></a></h3>
			<span><?php echo e($job->employer->employerCompanyInfo['name']); ?></span>
			<div class="job-lctn"><i class="la la-map-marker"></i><?php echo e($job->employer->employerCompanyInfo['city']); ?> / <?php echo e($job->employer->employerCompanyInfo['country']); ?></div>
			
		</div>
		<div class="job-style-bx">
			<span class="job-is ft">Full time</span>
			<?php if($job->vacancy): ?>
			<span class="mt-5 job-is ft">Vacancy - <?php echo e($job->vacancy); ?></span>
			<?php endif; ?>
			<i><i class="la la-clock-o"></i> <?php echo e(date("M d, Y", strtotime($job->deadline))); ?></i>
		</div>
	</div>