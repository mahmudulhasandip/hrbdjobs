<?php $__env->startSection('title', 'HRBDJobs | Employer Dashboard'); ?>

<?php $__env->startSection('content'); ?>
	<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(<?php echo e(asset('/images/top-bg.jpg')); ?>) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
				 			<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column">
				 		<div class="padding-left">
					 		<div class="manage-jobs-sec mb50">
					 			<h3>Packages</h3>
						 		

                                <div class="col-lg-12">
                                    <div class="tab-sec">
                                        <div class="job-listings-tabs">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <table class="table-fill">
                                                        <thead>
                                                            <tr>
                                                                <th>No.</th>
                                                                <th>Job Package</th>
                                                                <th>Featured Package</th>
                                                                <th>Expire Date</th>
                                                                <th>Remain post</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="table-hover">
                                                            <?php
                                                            $id = 1;
                                                            ?>
                                                            <?php $__currentLoopData = $packageHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($id++); ?></td>
                                                                <td><?php echo e(($packageHistory->job_package_id) ? $packageHistory->jobPackage->name : '-'); ?></td>
                                                                <td><?php echo e(($packageHistory->featured_package_id) ? $packageHistory->featuredPackage->name : '-'); ?></td>
                                                                <td><?php echo e($packageHistory->expired_date); ?></td>
                                                                <td><?php echo e($packageHistory->remain_amount); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
					 		</div>
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>