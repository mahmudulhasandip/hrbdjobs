<?php $__env->startSection('title', 'HRBDJobs | Candidate Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="overlape">
        <div class="block no-padding">
            <div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
            <div class="container fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner-header">
                            <h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="block no-padding">
            <div class="container">
                 <div class="row no-gape">
                    <aside class="col-lg-3 column border-right">
                        <div class="widget" id="sidebar">
                            <?php echo $__env->make('candidate.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        
                    </aside>
                    <div class="col-lg-9 column">
				 		<div class="padding-left">
					 		<div class="manage-jobs-sec">
					 			<div class="border-title"><h3>Followed Companies</h3></div>
					 			<?php $__currentLoopData = $followCompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 		<div id="follow-tab-<?php echo e($follow->employer_id); ?>" class="job-listing wtabs">
									<div class="job-title-sec newtab pointer" data-url="<?php echo e(route('company.profile', $follow->employer->employerCompanyInfo->id)); ?>">
										<div class="c-logo"> <img src="<?php echo e(( $follow->employer->employerCompanyInfo->logo ) ? asset('storage/uploads/'.$follow->employer->employerCompanyInfo->logo) : asset('storage/uploads/company-avatar.png')); ?>" alt="" /> </div>
										<h3><a href="javascript:void(0)" title=""><?php echo e($follow->employer->employerCompanyInfo->name); ?></a></h3>
                                        <?php
                                            $openingJob = App\Job::where('deadline', '>=', date('Y-m-d'))
                                                        ->where('is_paused', '=', 0)
                                                        ->where('is_verified', '=', 1)
                                                        ->where('employer_id', $follow->employer_id)
                                                        ->count();
                                        ?>
										<span><?php echo e($openingJob ? $openingJob.' Jobs opening': 'No Vacancy'); ?></span>
									</div>
									<div class="job-list-del">
										<span class="job-is ft"><a href="javascript:void(0)" data-employerId="<?php echo e($follow->employer_id); ?>" class="unfollow">Unfollow</a></span>
									</div>
								</div><!-- Job -->
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="margin-0 pagination-laravel">
                                    <?php echo e($followCompanies->links()); ?>

                                </div><!-- Pagination -->
					 		</div>
					 	</div>
					</div>
                 </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    var base_url = "<?php echo e(url('/candidate/')); ?>";
    $('.newtab').click(function() {
        window.open(
            $(this).data('url'),
            '_blank'
        );
    });
    $('.unfollow').click(function() {
        var employerId = $(this).data('employerid');
       
        $.ajax({
            url: base_url+"/follow/company/status/change",
            type: "post",
            headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
            data:{employer_id: employerId},
            success: function(message){
                iziToast.success({
                    title: message,
                    timeout: 2000,
                    overlay: true,
                    position: 'topRight',
                }); 

                $('#follow-tab-'+employerId).remove(); 
            }
        });
        
    });
</script>
<?php $__env->stopPush(); ?>





<?php echo $__env->make('candidate.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>