 
<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
 
<body>
<h2>Welcome to the site <?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?></h2>
<br/>
Your registered email-id is <?php echo e($user['email']); ?> , Please click on the below link to verify your email account
<br/>
<a href="<?php echo e(url('candidate/email/verify', $user->verifyCandidate->token)); ?>">Verify Email</a>
</body>
 
</html>