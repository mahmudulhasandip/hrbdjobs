<form method="post" action="<?php echo e(route('candidate.update.profile.basic')); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
		<div class="row">
		<div id="file-upload-form" class="uploader">
			<input id="file-upload" type="file" name="dp" accept="image/*" />

			<label for="file-upload" id="file-drag">
				<img id="file-image" src="<?php echo e(asset('storage/uploads/'.(($candidate->dp) ? $candidate->dp : 'default_user.png'))); ?>" alt="Preview" class="">
				<div id="start">
				<i class="fa fa-download" aria-hidden="true"></i>
				<div>Select a profile image or drag here</div>
				<div id="notimage" class="hidden">Please select an image</div>
				<span id="file-upload-btn" class="btn btn-primary">Select a file</span>
				</div>
				<div id="response" class="hidden">
				<div id="messages"></div>
				</div>
			</label>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">First Name</span>
			<div class="pf-field">
				<input type="text" name="fname" value="<?php echo e($candidate->fname); ?>" />
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Last Name</span>
			<div class="pf-field">
				<input type="text" name="lname" value="<?php echo e($candidate->lname); ?>" />
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Username</span>
			<div class="pf-field">
				<input type="text" name="username" value="<?php echo e($candidate->username); ?>" readonly />
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Email</span>
			<div class="pf-field">
				<input type="text" name="email" value="<?php echo e($candidate->email); ?>" readonly />
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Gender</span>
			<div class="pf-field">
				<select name="gender" data-placeholder="Allow In Search" class="chosen">
					<option value="Male" <?php echo e($candidate->gender == 'Male' ? 'selected':''); ?>>Male</option>
					<option value="Female" <?php echo e($candidate->gender == 'Female' ? 'selected':''); ?>>Female</option>
					<option value="Other" <?php echo e($candidate->gender == 'Other' ? 'selected':''); ?>>Other</option>
				</select>
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Birthday</span>
			<div class="pf-field">
				<input type="text" name="date_of_birth" id="datepicker" class="datepicker" value="<?php echo e(date('m/d/Y', strtotime(($candidate->date_of_birth) ? $candidate->date_of_birth : '01-01-1990'))); ?>">
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Country</span>
			<div class="pf-field">
				<select name="country" class="chosen">
					<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($candidate->country): ?>
						<option value="<?php echo e($country->name); ?>" <?php echo e(($candidate->country == $country->name) ? 'selected':''); ?>><?php echo e($country->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($country->name); ?>" <?php echo e(($country->name == 'Bangladesh') ? 'selected':''); ?>><?php echo e($country->name); ?></option>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">City</span>
			<div class="pf-field">
				<input type="text" name="city" value="<?php echo e($candidate->city); ?>" placeholder="Your City" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Current Address</span>
			<div class="pf-field">
				<textarea name="current_address" rows="2"><?php echo e($candidate->current_address); ?></textarea>
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Permanent Address</span>
			<div class="pf-field">
				<textarea name="permanent_address" rows="2"><?php echo e($candidate->permanent_address); ?></textarea>
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">Nationality</span>
			<div class="pf-field">
				<input type="text" name="nationality" value="<?php echo e($candidate->nationality); ?>" placeholder="Your Nationality" />
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">NID/Passport</span>
			<div class="pf-field">
				<input type="text" name="nid_passport" value="<?php echo e($candidate->nid_passport); ?>" placeholder="Your NID or Passport" />
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">Contact No</span>
			<div class="pf-field">
				<input type="text" name="phone" value="<?php echo e($candidate->phone); ?>" placeholder="Your Contact Number" />
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">Marital Status</span>
			<div class="pf-field">
				<select name="marital_status" data-placeholder="Please Select Specialism" class="chosen">
					<option value="Unmarried" <?php echo e($candidate->marital_status == 'Unmarried' ? 'selected':''); ?>>Unmarried</option>
					<option value="Married" <?php echo e($candidate->marital_status == 'Married' ? 'selected':''); ?>>Married</option>
					<option value="Divorced" <?php echo e($candidate->marital_status == 'Divorced' ? 'selected':''); ?>>Divorced</option>
				</select>
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">Father's Name</span>
			<div class="pf-field">
				<input type="text" name="father_name" value="<?php echo e($candidate->father_name); ?>" placeholder="Your Father Name" />
			</div>
		</div>

		<div class="col-lg-3">
			<span class="pf-title">Mother's Name</span>
			<div class="pf-field">
				<input type="text" name="mother_name" value="<?php echo e($candidate->mother_name); ?>" placeholder="Your Mother Name" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Spouse Name</span>
			<div class="pf-field">
				<input type="text" name="spouse_name" value="<?php echo e($candidate->spouse_name); ?>" placeholder="Your Mother Name" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Website</span>
			<div class="pf-field">
				<input type="text" name="website" value="<?php echo e($candidate->website); ?>" placeholder="www.example.com" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Linkedin</span>
			<div class="pf-field">
				<input type="text" name="linkedin" value="<?php echo e($candidate->linkedin); ?>" placeholder="www.linkedin.com/in/exapmle123/" />
			</div>
		</div>

		<div class="col-lg-12">
			<span class="pf-title">Summary</span>
			<div class="pf-field">
				<textarea name="about_me" rows="5"><?php echo e($candidate->about_me); ?></textarea>
			</div>
		</div>

		<div class="col-lg-12">
			<h3 class="text-center">Skill Info</h3>
		</div>

		<div class="col-md-6">
			<span class="pf-title">Experience (Years)</span>
			<div class="pf-field">
				<select name="experience" data-placeholder="Please Select Specialism" class="chosen">
					<?php $__currentLoopData = $jobExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobExperience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($jobExperience->id); ?>" <?php echo e((sizeof($candidateSkills) && ($candidateSkills[0]->experience == $jobExperience->id)) ? 'selected':''); ?>><?php echo e($jobExperience->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-6">
			<span class="pf-title">Job Level</span>
			<div class="pf-field">
				<select name="job_level" data-placeholder="Please Select Specialism" class="chosen">
					<?php $__currentLoopData = $jobLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($jobLevel->id); ?>" <?php echo e((sizeof($candidateSkills) && ($candidateSkills[0]->job_level == $jobLevel->id)) ? 'selected':''); ?>><?php echo e($jobLevel->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-6">
			<span class="pf-title">Job Category</span>
			<div class="pf-field">
				<select name="job_category" data-placeholder="Please Select Specialism" class="chosen">
					<?php $__currentLoopData = $jobCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($jobCategory->id); ?>" <?php echo e((sizeof($candidateSkills) && ($candidateSkills[0]->category_id == $jobCategory->id)) ? 'selected':''); ?>><?php echo e($jobCategory->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-6">
			<span class="pf-title">Job Designation</span>
			<div class="pf-field">
				<select name="job_designation" data-placeholder="Please Select Specialism" class="chosen">
					<?php $__currentLoopData = $jobDesignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobDesignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($jobDesignation->id); ?>" <?php echo e((sizeof($candidateSkills) && ($candidateSkills[0]->designation_id == $jobDesignation->id)) ? 'selected':''); ?>><?php echo e($jobDesignation->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>
		
		<div class="col-lg-12">
			<span class="pf-title">Expertise Area</span>
			<div class="pf-field no-margin">
				<?php 
					$canSkills = array();
					if(sizeof($candidateSkills)){
						foreach ($candidateSkills as $skill) {
							$canSkills[] = $skill->expertise_area;
						}
					}
					
				?>

				<select multiple="multiple" class="req-skill"  name="expertise_area[]">
					<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($skill->id); ?>"  <?php echo e((in_array($skill->id, $canSkills)) ? 'selected':''); ?>><?php echo e($skill->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>
		
		<div class="col-lg-12">
			<button type="submit">Update</button>
		</div>
	</div>
</form>
