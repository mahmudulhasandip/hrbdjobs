<?php $__env->startSection('title', 'HRBDJobs | Candidate Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="overlape">
        <div class="block no-padding">
            <div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
            <div class="container fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner-header">
                            <h3>Applied Jobs</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="block no-padding">
            <div class="container">
                 <div class="row no-gape">
                    <aside class="col-lg-3 column border-right">
                        <div class="widget" id="sidebar">
                            <?php echo $__env->make('candidate.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        
                    </aside>
                    <div id="wall" class="col-lg-9 column">
                        <div class="padding-left">
                            <div class="manage-jobs-sec">
                                <h3>Manage Applied Jobs (<i class="text-default">Total <?php echo e($total); ?> jobs applied</i> )</h3>
                                <table>
                                    <thead>
                                        <tr>
                                            <td>Applied Job</td>
                                            <td>Position</td>
                                            <td>Date</td>
                                            <td></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $applied_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app_job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="job-tab-<?php echo e($app_job->job_id); ?>">
                                            <td class="pointer newtab" data-url="<?php echo e(route('single.job', $app_job->job_id)); ?>">
                                                <div class="table-list-title">
                                                    <i><?php echo e($app_job->job->employer->employerCompanyInfo->name); ?></i><br />
                                                    <span><i class="la la-map-marker"></i><?php echo e($app_job->job->location); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="pointer newtab table-list-title" data-url="<?php echo e(route('single.job', $app_job->job_id)); ?>">
                                                    <h3><a href="<?php echo e(route('single.job', $app_job->job_id)); ?>" title=""><?php echo e($app_job->job->title); ?></a></h3>
                                                </div>
                                            </td>
                                            <td>
                                                <span><?php echo e(date("M d, Y", strtotime($app_job->created_at))); ?></span><br />
                                            </td>
                                            <td>
                                                <ul class="action_job">
                                                    <li class="pointer"><span>Withdraw</span><a href="javascript:void(0)" class="withdraw-job" data-jobId="<?php echo e($app_job->job_id); ?>"><i class="la la-close"></i></a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="margin-0 pagination-laravel">
                                    <?php echo e($applied_jobs->links()); ?>

                                </div><!-- Pagination -->
                            </div>
                        </div>
                    </div>
                 </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    var base_url = "<?php echo e(url('/candidate/')); ?>";
    $('.newtab').click(function() {
        window.open(
            $(this).data('url'),
            '_blank'
        );
    });
    $('.withdraw-job').click(function() {
        var jobId = $(this).data('jobid');
       
        $.ajax({
            url: base_url+"/applied/job/withdraw",
            type: "post",
            headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
            data:{job_id: jobId},
            success: function(message){
                iziToast.success({
                    title: message,
                    timeout: 2000,
                    overlay: true,
                    position: 'topRight',
                }); 

                $('#job-tab-'+jobId).remove(); 
            }
        });
        
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('candidate.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>