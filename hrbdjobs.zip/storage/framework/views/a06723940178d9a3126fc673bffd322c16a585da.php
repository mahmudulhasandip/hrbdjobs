<?php if(sizeof($candidateTrainings)): ?>
	<form method="post" action="<?php echo e(route('candidate.update.profile.training')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col-lg-12">
				<div class="row">
					<?php $__currentLoopData = $candidateTrainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-12">
									<h4 class="text-center">Training Summary</h4>
									<hr>
								</div>
								<div class="col-lg-6">
									<span class="pf-title">Title</span>
									<div class="pf-field">
										<input type="text" name="title[]" value="<?php echo e($training->title); ?>" required />
									</div>
								</div>


								<div class="col-lg-6">
									<span class="pf-title">Country</span>
									<div class="pf-field">
										<select name="country[]" class="chosen">
											<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($training->country): ?>
													<option value="<?php echo e($country->name); ?>" <?php echo e(($training->country == $country->name) ? 'selected':''); ?>><?php echo e($country->name); ?></option>
												<?php else: ?>
													<option value="<?php echo e($country->name); ?>" <?php echo e(($country->name == 'Bangladesh') ? 'selected':''); ?>><?php echo e($country->name); ?></option>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Topic Cover</span>
									<div class="pf-field">
										<input type="text" name="topic_cover[]" value="<?php echo e($training->topic_cover); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Training Year</span>
									<div class="pf-field">
										<input type="number" name="training_year[]" value="<?php echo e($training->training_year); ?>"/>
									</div>
								</div>

								<div class="col-lg-4">
									<span class="pf-title">Institution Name</span>
									<div class="pf-field">
										<input type="text" name="institution_name[]" value="<?php echo e($training->institution_name); ?>" />
									</div>
								</div>

								<div class="col-lg-4">
									<span class="pf-title">Duration (Month)</span>
									<div class="pf-field">
										<input type="number" name="duration[]" value="<?php echo e($training->duration); ?>" required />
									</div>
								</div>

								<div class="col-lg-4">
									<span class="pf-title">Location</span>
									<div class="pf-field">
										<input type="text" name="location[]" value="<?php echo e($training->location); ?>" />
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-12" id="make_clone_box_training">
				
			</div>
			<div class="col-lg-12">
				<a href="javascript:void(0)" onclick="makeBox('training')" id="add_training" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Training</a>
				<button type="submit">Update</button>
			</div>
		</div>
	</form>
<?php else: ?>
<form method="post" action="<?php echo e(route('candidate.update.profile.training')); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<div class="row">
		
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="text-center">Training Summary</h4>
					<hr>
				</div>
				<div class="col-lg-6">
					<span class="pf-title">Title</span>
					<div class="pf-field">
						<input type="text" name="title[]" required />
					</div>
				</div>


				<div class="col-lg-6">
					<span class="pf-title">Country</span>
					<div class="pf-field">
						<select name="country[]" class="chosen">
							<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($country->name); ?>" <?php echo e(($country->name == 'Bangladesh') ? 'selected':''); ?>><?php echo e($country->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Topic Cover</span>
					<div class="pf-field">
						<input type="text" name="topic_cover[]" />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Training Year</span>
					<div class="pf-field">
						<input type="number" name="training_year[]" />
					</div>
				</div>

				<div class="col-lg-4">
					<span class="pf-title">Institution Name</span>
					<div class="pf-field">
						<input type="text" name="institution_name[]" />
					</div>
				</div>

				<div class="col-lg-4">
					<span class="pf-title">Duration (Month)</span>
					<div class="pf-field">
						<input type="text" name="duration[]" required />
					</div>
				</div>

				<div class="col-lg-4">
					<span class="pf-title">Location</span>
					<div class="pf-field">
						<input type="text" name="location[]" />
					</div>
				</div>
			</div>
			<div class="col-lg-12" id="make_clone_box_training">
				
			</div>
		</div>
		<div class="col-lg-12">
			<a href="javascript:void(0)" onclick="makeBox('training')" id="add_education" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Training</a>
			<button type="submit">Update</button>
		</div>
	</div>
</form>
<?php endif; ?>

<div id="make_clone_training" class="hidden">
	<div class="row">

		<div class="col-lg-12">
			<h4 class="text-center">Training Summary</h4>
			<hr>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Title</span>
			<div class="pf-field">
				<input type="text" name="title[]"/>
			</div>
		</div>


		<div class="col-lg-6">
			<span class="pf-title">Country</span>
			<div class="pf-field">
				<select name="country[]" class="chosen">
					<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($country->name); ?>" <?php echo e(($country->name == 'Bangladesh') ? 'selected':''); ?>><?php echo e($country->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Topic Cover</span>
			<div class="pf-field">
				<input type="text" name="topic_cover[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Training Year</span>
			<div class="pf-field">
				<input type="number" name="training_year[]" />
			</div>
		</div>

		<div class="col-lg-4">
			<span class="pf-title">Institution Name</span>
			<div class="pf-field">
				<input type="text" name="institution_name[]" />
			</div>
		</div>

		<div class="col-lg-4">
			<span class="pf-title">Duration (Month)</span>
			<div class="pf-field">
				<input type="text" name="duration[]" />
			</div>
		</div>

		<div class="col-lg-4">
			<span class="pf-title">Location</span>
			<div class="pf-field">
				<input type="text" name="location[]" />
			</div>
		</div>
	</div>
</div>
