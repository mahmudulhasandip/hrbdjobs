<div class="responsive-header">
    <div class="responsive-menubar">
        <div class="res-logo"><a href="<?php echo e(url('/')); ?>" title=""><img src="/images/logo.png" alt="" /></a></div>
        <div class="menu-resaction">
            <div class="res-openmenu">
                <img src="/images/icon.png" alt="" /> Menu
            </div>
            <div class="res-closemenu">
                <img src="/images/icon2.png" alt="" /> Close
            </div>
        </div>
    </div>
    <div class="responsive-opensec">
        <div class="btn-extars">
            <?php if(Auth::guard('candidate')->user()): ?>
               <a href="<?php echo e(route('candidate.home')); ?>" title="">
                    <div class="btns-profiles-sec">
                        <span><img src="<?php echo e(asset('storage/uploads/'.((Auth::guard('candidate')->user()->dp) ? Auth::guard('candidate')->user()->dp : 'default_user.png'))); ?>"><?php echo e(Auth::guard('candidate')->user()->fname); ?></span>
                    </div>
                </a>
            <?php endif; ?>   
            <?php if(Auth::guard('employer')->user()): ?>
                <a href="<?php echo e(route('employer.new.job')); ?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                <a href="<?php echo e(route('employer.home')); ?>" title="" >
                    <div class="btns-profiles-sec">
                        <span><img src="<?php echo e(asset('storage/uploads/'.((Auth::guard('employer')->user()->employerCompanyInfo->logo) ? Auth::guard('employer')->user()->employerCompanyInfo->logo : 'default_user.png'))); ?>"><?php echo e(Auth::guard('employer')->user()->fname); ?></span>
                    </div>
                </a>
            <?php endif; ?>
            <?php if(!Auth::guard('employer')->user() && !Auth::guard('candidate')->user()): ?>
                <a href="<?php echo e(route('employer.new.job')); ?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                <ul class="account-btns">
                    <li class="signup-popup"><a title=""><i class="la la-key"></i> Sign Up</a></li>
                    <li class="signin-popup"><a title=""><i class="la la-external-link-square"></i> Login</a></li>
                </ul>
            <?php endif; ?>
        </div><!-- Btn Extras -->
        <form action="<?php echo e(url('/browse/jobs')); ?>" method="get" class="res-search">
            <input type="text" name="keyword" placeholder="Job title, keywords or company name" />
            <button type="submit"><i class="la la-search"></i></button>
        </form>
        <div class="responsivemenu">
                <ul>
                    <li class="">
                        <a href="<?php echo e(url('/')); ?>" title="">Home</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(url('/browse/jobs')); ?>" title="">Browse Jobs</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('about.us')); ?>" title="">About</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('contact.us')); ?>" title="">Contact</a>
                    </li>
                </ul>
        </div>
    </div>
</div>

<?php if($page == 'home'): ?>
<header class="stick-top forsticky">
<?php else: ?>
<header class="stick-top forsticky white sticky">
<?php endif; ?>
    <div class="menu-sec">
        <div class="container">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>" title=""><img class="hidesticky" src="/images/logo.png" alt="" /><img class="showsticky" src="/images/logo-2.png" alt="" /></a>
            </div><!-- Logo -->
            <?php if(Auth::guard()->user()): ?>
            <style>
                .btns-profiles-sec{padding: 3px 15px;}
                @media (max-width: 520px){
                    .responsive-opensec .post-job-btn {
                        padding: 8px 5px;
                        margin-top: 10px;
                    }
                    .btns-profiles-sec {
                        padding: 3px 10px;
                    }
                }
                    
            </style>
            <?php endif; ?>
            <div class="btn-extars">
                <?php if(Auth::guard('candidate')->user()): ?>
                    <a href="<?php echo e(route('candidate.home')); ?>" title="">
                        <div class="btns-profiles-sec">
                            <span><img src="<?php echo e(asset('storage/uploads/'.((Auth::guard('candidate')->user()->dp) ? Auth::guard('candidate')->user()->dp : 'default_user.png'))); ?>"><?php echo e(Auth::guard('candidate')->user()->fname); ?></span>
                        </div>
                    </a>
                <?php endif; ?>   
                <?php if(Auth::guard('employer')->user()): ?>
                    <a href="<?php echo e(route('employer.new.job')); ?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                    <a href="<?php echo e(route('employer.home')); ?>" title="" >
                        <div class="btns-profiles-sec">
                            <span><img src="<?php echo e(asset('storage/uploads/'.((Auth::guard('employer')->user()->employerCompanyInfo->logo) ? Auth::guard('employer')->user()->employerCompanyInfo->logo : 'default_user.png'))); ?>"><?php echo e(Auth::guard('employer')->user()->fname); ?></span>
                        </div>
                    </a>
                <?php endif; ?>
                <?php if(!Auth::guard('employer')->user() && !Auth::guard('candidate')->user()): ?>
                    <a href="<?php echo e(route('employer.new.job')); ?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                    <ul class="account-btns">
                        <li class="signup-popup"><a title=""><i class="la la-key"></i> Sign Up</a></li>
                        <li class="signin-popup"><a title=""><i class="la la-external-link-square"></i> Login</a></li>
                    </ul>
                <?php endif; ?>
            </div><!-- Btn Extras -->
            <nav>
                <ul>
                    <li class="">
                        <a href="<?php echo e(url('/')); ?>" title="">Home</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(url('/browse/jobs')); ?>" title="">Browse Jobs</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('about.us')); ?>" title="">About</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('contact.us')); ?>" title="">Contact</a>
                    </li>
                </ul>
            </nav><!-- Menus -->
        </div>
    </div>
</header>