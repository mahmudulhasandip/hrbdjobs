<?php $__env->startSection('title', 'HRBDJobs | Employer Shortlisted Candidate'); ?>

<?php $__env->startSection('content'); ?>
	<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(/images/top-bg.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
							<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column mb-50">
				 		<div class="padding-left">

							<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="widget shortlist">
								<h3 class="sb-title open active close"><?php echo e($job->title); ?></h3>
                                <div class="tree_widget-sec" >
                                    <ul>
										
										<?php $__currentLoopData = $job->appliedJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app_job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($app_job->is_short_listed): ?>
                                        <li class="inner-child">
                                            <a class="title" href="<?php echo e(route('employer.public.candidate.resume', $app_job->candidate->id)); ?>" target="_blank"><?php echo e($app_job->candidate->fname); ?> <?php echo e($app_job->candidate->lname); ?></a>
											<span style="display:block;"><?php echo e($app_job->candidate->candidateSkill->first()['experience']); ?> <?php echo e(( $app_job->candidate->candidateSkill->first()['experience'])?'year':''); ?><?php echo e(( $app_job->candidate->candidateSkill->first()['experience']>1)?'s':''); ?></span>
											
											<a href="javascript:;" class="shortListCandidate del-resume" data-jobId="<?php echo e($app_job->job_id); ?>" data-candidateId="<?php echo e($app_job->candidate_id); ?>"><i class="la la-trash-o"></i></a>
										</li>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
	var base_url = "<?php echo e(url('/employer/')); ?>";
	$('.shortListCandidate').click(function() {
        var candidateId = $(this).data('candidateid');
		var jobId = $(this).data('jobid');
        $.ajax({
            url: base_url+"/job/candidates/applied/shortListed/",
            type: "post",
            headers: {'X-CSRF-TOKEN': Laravel.csrfToken},
            data:{candidate_id: candidateId, job_id: jobId},
            success: function(message){
                iziToast.success({
                    title: message,
                    timeout: 2000,
                    overlay: true,
                    position: 'topRight',
                });

            
            }
        });
        
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>