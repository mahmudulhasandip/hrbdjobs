<?php if(sizeof($candidateExperiences)): ?>
	<form method="post" action="<?php echo e(route('candidate.update.profile.experience')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col-lg-12">
				<div class="row">
					<?php $__currentLoopData = $candidateExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-12">
							<div class="row">
								<div class="col-lg-12">
									<h4 class="text-center">Experience Summary</h4>
									<hr>
								</div>
								<div class="col-lg-6">
									<span class="pf-title">Company Name</span>
									<div class="pf-field">
										<input type="text" name="company_name[]" value="<?php echo e($experience->company_name); ?>" required />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Responsibility</span>
									<div class="pf-field">
										<input type="text" name="responsibility[]" value="<?php echo e($experience->responsibility); ?>" />
									</div>
								</div>

								<div class="col-md-6">
									<span class="pf-title">Candidate Designation</span>
									<div class="pf-field">
										<select name="candidate_designation[]" data-placeholder="Please Select Specialism" class="chosen">
											<?php $__currentLoopData = $jobDesignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobDesignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($jobDesignation->id); ?>" <?php echo e(($experience->candidate_designation == $jobDesignation->id) ? 'selected':''); ?>><?php echo e($jobDesignation->name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Company Designation</span>
									<div class="pf-field">
										<input type="text" name="company_designation[]" value="<?php echo e($experience->company_designation); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">Start Date</span>
									<div class="pf-field">
										<input type="text" name="start_date[]" class="datepicker" value="<?php echo e($experience->start_date); ?>" />
									</div>
								</div>

								<div class="col-lg-6">
									<span class="pf-title">End Date</span>
									<div class="pf-field">
										<input type="text" name="end_date[]" class="datepicker" value="<?php echo e($experience->end_date); ?>" />
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-lg-12" id="make_clone_box_experience">
				
			</div>
			<div class="col-lg-12">
				<a href="javascript:void(0)" onclick="makeBox('experience')" id="add_experience" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Experience</a>
				<button type="submit">Update</button>
			</div>
		</div>
	</form>
<?php else: ?>
<form method="post" action="<?php echo e(route('candidate.update.profile.experience')); ?>" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<div class="row">
		
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-12">
					<h4 class="text-center">Experience Summary</h4>
					<hr>
				</div>
				<div class="col-lg-6">
					<span class="pf-title">Company Name</span>
					<div class="pf-field">
						<input type="text" name="company_name[]" required />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Responsibility</span>
					<div class="pf-field">
						<input type="text" name="responsibility[]" required />
					</div>
				</div>

				<div class="col-md-6">
					<span class="pf-title">Candidate Designation</span>
					<div class="pf-field">
						<select name="candidate_designation[]" data-placeholder="Please Select Specialism" class="chosen">
							<?php $__currentLoopData = $jobDesignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobDesignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($jobDesignation->id); ?>"><?php echo e($jobDesignation->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Company Designation</span>
					<div class="pf-field">
						<input type="text" name="company_designation[]" required />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">Start Date</span>
					<div class="pf-field">
						<input type="text" name="start_date[]" class="datepicker" required />
					</div>
				</div>

				<div class="col-lg-6">
					<span class="pf-title">End Date</span>
					<div class="pf-field">
						<input type="text" name="end_date[]" class="datepicker" />
					</div>
				</div>
			<div class="col-lg-12" id="make_clone_box_experience">
				
			</div>
		</div>
		<div class="col-lg-12">
			<a href="javascript:void(0)" onclick="makeBox('experience')" id="add_experience" class="margin_top_25 text-blue"><span class="la la-plus"></span> Add Experience</a>
			<button type="submit">Update</button>
		</div>
	</div>
</form>
<?php endif; ?>

<div id="make_clone_experience" class="hidden">
	<div class="row">

		<div class="col-lg-12">
			<h4 class="text-center">Experience Summary</h4>
			<hr>
		</div>
		<div class="col-lg-6">
			<span class="pf-title">Company Name</span>
			<div class="pf-field">
				<input type="text" name="company_name[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Responsibility</span>
			<div class="pf-field">
				<input type="text" name="responsibility[]" />
			</div>
		</div>

		<div class="col-md-6">
			<span class="pf-title">Candidate Designation</span>
			<div class="pf-field">
				<select name="candidate_designation[]" data-placeholder="Please Select Specialism" class="chosen">
					<?php $__currentLoopData = $jobDesignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobDesignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($jobDesignation->id); ?>" ><?php echo e($jobDesignation->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Company Designation</span>
			<div class="pf-field">
				<input type="text" name="company_designation[]" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">Start Date</span>
			<div class="pf-field">
				<input type="text" name="start_date[]" class="datepicker" />
			</div>
		</div>

		<div class="col-lg-6">
			<span class="pf-title">End Date</span>
			<div class="pf-field">
				<input type="text" name="end_date[]" class="datepicker" />
			</div>
		</div>
	</div>
</div>
