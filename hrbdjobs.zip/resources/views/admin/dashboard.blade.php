@extends('admin.layout.admin')

@section('content')
<div class="m-content">
    <h1>Welcome to Admin Dashboard</h1>
</div>
@endsection
