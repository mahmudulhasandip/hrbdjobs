<?php $__env->startSection('title', 'HRBDJobs | Manage Job'); ?>

<?php $__env->startSection('content'); ?>
<section class="overlape">
		<div class="block no-padding">
			<div data-velocity="-.1" style="background: url(<?php echo e(asset('/images/top-bg.jpg')); ?>) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div><!-- PARALLAX BACKGROUND IMAGE -->
			<div class="container fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="inner-header">
							<h3>Welcome <?php echo e(Auth::user()->fname.' '. Auth::user()->lname); ?></h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="block no-padding">
			<div class="container">
				 <div class="row no-gape">
				 	<aside class="col-lg-3 column border-right">
				 		<div class="widget">
							<?php echo $__env->make('employer.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				 		</div>
				 		
				 	</aside>
				 	<div class="col-lg-9 column">
				 		<div class="padding-left">
					 		<div class="manage-jobs-sec">
					 			<h3>Manage Jobs</h3>
					 			<div class="extra-job-info">
									 <span><i class="la la-clock-o"></i> <strong>
											<?php echo e(($totalJobs) > 0 ? $totalJobs : 0); ?>

									 </strong> Job Posted</span>
						 			<span><i class="la la-file-text"></i><strong>20</strong> Application</span>
									 <span><i class="la la-users"></i>
										<strong>
											<?php echo e((($activeJobs) > 0 ? $activeJobs : 0)); ?>

										</strong>
										 Active Jobs</span>
						 		</div>
						 		<table>
						 			<thead>
						 				<tr>
						 					<td>Title</td>
						 					<td>Applications</td>
						 					<td>Created & Expired</td>
						 					<td>Status</td>
						 					<td>Action</td>
						 				</tr>
						 			</thead>
						 			<tbody>

										<?php $__currentLoopData = $allJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php
										$year = $job->created_at->year;
										$month = $job->created_at->month;
										$day = $job->created_at->day;
										?>
						 				<tr>
						 					<td>
						 						<div class="table-list-title">
												 <h3><a href="/employer/job_details/<?php echo e($job->id); ?>" title=""><?php echo e($job->title); ?></a></h3>
						 						</div>
						 					</td>
						 					<td>
						 						<span class="applied-field">3+ Applied</span>
						 					</td>
						 					<td>
						 						<span><?php echo e($year ."-". $month ."-". $day); ?></span><br />
						 						<span><?php echo e($job->deadline); ?></span>
						 					</td>
						 					<td>
						 						<span class="status  <?php echo e(($job->is_varified) ? 'active' : 'inactive'); ?> "><?php echo e(($job->is_varified) ? 'Active' : 'Inactive'); ?></span>
						 					</td>
						 					<td>
						 						<ul class="action_job">
						 							<li><span>View Job</span><a href="#" title=""><i class="la la-eye"></i></a></li>
						 							<li><span>Edit</span><a href="#" title=""><i class="la la-pencil"></i></a></li>
						 							<li><span>Delete</span><a href="#" title=""><i class="la la-trash-o"></i></a></li>
						 						</ul>
						 					</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 			</tbody>
						 		</table>
					 		</div>
					 	</div>
					</div>
				 </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>