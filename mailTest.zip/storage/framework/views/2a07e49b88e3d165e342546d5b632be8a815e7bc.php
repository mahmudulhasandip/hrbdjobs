<?php $__env->startSection('title', 'HRBD Jobs | Employer Login'); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="block no-padding  gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner2">
                        <div class="inner-title2">
                            <h3>Login</h3>
                            <span>Keep up to date with the latest news</span>
                        </div>
                        <div class="page-breacrumbs">
                            <ul class="breadcrumbs">
                                <li><a href="#" title="">Home</a></li>
                                <li><a href="#" title="">Pages</a></li>
                                <li><a href="#" title="">Login</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="block remove-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="account-popup-area signin-popup-box static">
                        <div class="account-popup">
                            <span>Lorem ipsum dolor sit amet consectetur adipiscing elit odio duis risus at lobortis ullamcorper</span>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('warning')): ?>
                                <div class="alert alert-warning">
                                    <?php echo e(session('warning')); ?>

                                </div>
                            <?php endif; ?>
                            <form role="form" method="POST" action="<?php echo e(url('/employer/login')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="cfield <?php echo e($errors->has('username') ? ' has-error' : ''); ?>" >
                                    <input id="username" type="text" class="form-control" placeholder="Email or Username" name="username" value="<?php echo e(old('username')); ?>" autofocus>
                                    <i class="la la-user"></i>
                                    <?php if($errors->has('username')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="cfield <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <input id="password" type="password" class="form-control" placeholder="*******" name="password">
                                    <i class="la la-key"></i>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <p class="remember-label">
                                    <input type="checkbox" name="remember" id="cb1"><label for="cb1">Remember me</label>
                                </p>
                                <a class="btn btn-link" href="<?php echo e(url('/candidate/password/reset')); ?>">
                                    Forgot Your Password?
                                </a>
                                <button type="submit">Login</button>
                            </form>
                            <div class="extra-login">
                                <span>Or</span>
                                <div class="login-social">
                                    <a class="google-login" href="#" title=""><i class="fa fa-google"></i></a>
                                    <!-- <a class="tw-login" href="#" title=""><i class="fa fa-twitter"></i></a> -->
                                </div>
                            </div>
                        </div>
                    </div><!-- LOGIN POPUP -->
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>