 
<?php $__env->startSection('title', 'HRBD Jobs | Employer Register'); ?> 
<?php $__env->startSection('content'); ?>
<section>
    <div class="block no-padding  gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner2">
                        <div class="inner-title2">
                            <h3>Employer Signup</h3>
                            <!-- <span>Keep up to date with the latest news</span> -->
                        </div>
                        <!-- <div class="page-breacrumbs">
                            <ul class="breadcrumbs">
                                <li><a href="#" title="">Home</a></li>
                                <li><a href="#" title="">Pages</a></li>
                                <li><a href="#" title="">Login</a></li>
                            </ul>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="block remove-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="account-popup-area signin-popup-box static">
                        
                        <div class="account-popup signup ">
                            <form class="mb-50" role="form" method="POST" action="<?php echo e(url('/employer/register')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <!-- account info -->
                                <h1>Account Info</h1>
                                <div class="cfield col-sm-12 <?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                    <input type="text" placeholder="Username" name="username" />
                                    <i class="la la-user"></i> <?php if($errors->has('username')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="password" placeholder="Password" name="password" />
                                    <i class="la la-key"></i> <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="password" placeholder="Confirm Password" name="password_confirmation" />
                                    <i class="la la-key"></i>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="Your First Name" name="fname" />
                                    <i class="la la-user"></i> <?php if($errors->has('fname')): ?>
                                    <span class="help-block">
                                                <strong><?php echo e($errors->first('fname')); ?></strong>
                                            </span> <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="Your Last Name" name="lname" />
                                    <i class="la la-user"></i> <?php if($errors->has('lname')): ?>
                                    <span class="help-block">
                                                <strong><?php echo e($errors->first('lname')); ?></strong>
                                            </span> <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="Person Designation" name="person_designation" />
                                    <i class="la la-certificate"></i> <?php if($errors->has('person_designation')): ?>
                                    <span class="help-block">
                                                <strong><?php echo e($errors->first('person_designation')); ?></strong>
                                            </span> <?php endif; ?>
                                </div>


                                <div class="cfield col-sm-6">
                                    <input type="email" placeholder="Person Email" name="person_email" />
                                    <i class="la la-envelope"></i> <?php if($errors->has('person_email')): ?>
                                    <span class="help-block">
                                                <strong><?php echo e($errors->first('person_email')); ?></strong>
                                            </span> <?php endif; ?>
                                </div>


                                <!-- company details -->
                                <h1>Company Details</h1>
                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="Company Name" name="name" />
                                    <i class="la la-building"></i> <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <div class="col-sm-6 dropdown-field">

                                    <select name="industry_type[]" id="industry_type" autocomplete="off" data-placeholder="Choose Industry ..." multiple class="chosen form-control">
                                        <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($industry->id); ?>"><?php echo e($industry->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> <?php if($errors->has('industry_type')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('industry_type')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>




                                <div class="pf-field col-sm-12">
                                    <textarea name="description" placeholder="Brief About Company"></textarea> <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>


                                <!-- primary Contact Details -->
                                
                                <div class="pf-field col-sm-6">
                                    <textarea name="address" placeholder="Company Address"></textarea> <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <div class="pf-field col-sm-6">
                                    <textarea name="billing_address" placeholder="Billing Address"></textarea> <?php if($errors->has('billing_address')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('billing_address')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="City" name="city" />
                                    <i class="la la-map"></i> <?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                                    <strong><?php echo e($errors->first('city')); ?></strong>
                                                </span> <?php endif; ?>
                                </div>
                                <div class="col-sm-6 dropdown-field">

                                    <select name="country" id="country" autocomplete="off" data-placeholder="Choose Company Category" class="chosen form-control">
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->name); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select> 
                                        <?php if($errors->has('country')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('country')); ?></strong>
                                        </span> 
                                        <?php endif; ?>
                                </div>

                                <div class="cfield col-sm-6">
                                    <div class="cfield col-sm-6" style="padding-left: 0;">
                                        <input type="number" placeholder="Contact Phone" name="contact_phone" />
                                        <i class="la la-phone"></i> <?php if($errors->has('contact_phone')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('contact_phone')); ?></strong>
                                            </span> <?php endif; ?>
                                    </div>
                                    <div class="cfield col-sm-6" style="padding-right: 0;">
                                        <input type="email" placeholder="Contact Email" name="contact_email" />
                                        <i class="la la-user"></i> <?php if($errors->has('contact_email')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('contact_email')); ?></strong>
                                            </span> <?php endif; ?>
                                    </div>
                                </div>

                                <div class="cfield col-sm-6">
                                    <input type="text" placeholder="Website" name="website" />
                                    <i class="la la-globe"></i> <?php if($errors->has('website')): ?>
                                    <span class="help-block">
                                            <strong><?php echo e($errors->first('website')); ?></strong>
                                        </span> <?php endif; ?>
                                </div>

                                <button type="submit">Sign Up</button>
                            </form>
                            
                        </div>
                    </div>
                    <!-- LOGIN POPUP -->
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employer.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>