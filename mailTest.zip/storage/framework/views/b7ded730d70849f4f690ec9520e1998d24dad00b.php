


<?php if(session('status')): ?>
    <?php $__env->startPush('js'); ?>

    <script>
        toastr.success('<?php echo e(session('status')); ?>');
    </script>

    <?php $__env->stopPush(); ?>
<?php endif; ?>